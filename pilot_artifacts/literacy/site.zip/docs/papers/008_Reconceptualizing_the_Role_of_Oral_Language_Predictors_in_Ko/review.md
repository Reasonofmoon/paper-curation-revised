---
schema_version: v1
title: "Reconceptualizing the Role of Oral Language Predictors in Korean EFL Learners’ Reading Comprehension"
authors:
  - "Jeeyoung Park"
  - "Yusun Kang"
date: "2025"
doi: "10.15858/engtea.80.2.202506.83"
license: "CC BY"
journal: "English Teaching"
essence: "한국 대학생 고급 EFL 학습자를 대상으로, 듣기·문법·어휘 폭·어휘 깊이를 통합한 구어언어이해(OLC)와 어휘 깊이가 각각 읽기이해에 독립적으로 기여하며, 그 중 OLC의 예측력이 상대적으로 더 강하다는 것을 SEM으로 밝힌 연구이다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Reconceptualizing the Role of Oral Language Predictors in Korean EFL Learners’ Reading Comprehension

> **저자**: Jeeyoung Park, Yusun Kang | **날짜**: 2025 | **DOI**: [10.15858/engtea.80.2.202506.83](https://doi.org/10.15858/engtea.80.2.202506.83)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: reading-comprehension

---

## Essence

한국 대학생 고급 EFL 학습자를 대상으로, 듣기·문법·어휘 폭·어휘 깊이를 통합한 구어언어이해(OLC)와 어휘 깊이가 각각 읽기이해에 독립적으로 기여하며, 그 중 OLC의 예측력이 상대적으로 더 강하다는 것을 SEM으로 밝힌 연구이다.

## 연구 질문과 배경

선행 연구들은 구어언어이해(OLC)의 하위요소(듣기, 문법, 어휘 폭 등)를 개별적으로 다루거나 일부만 잠재변인으로 통합해 다루었고, 어휘 깊이의 고유한 역할도 OLC나 어휘 폭과 혼동되어 다뤄져 왔음. 이에 본 연구는 OLC를 기초 언어변인들의 통합된 단일 구성체로 개념화하여 그 종합적 기여를 살펴보고, 이를 어휘 깊이의 효과와 비교하면서 쓰기능력도 함께 고려하여 고급 한국 EFL 학습자의 읽기이해를 예측하는 요인을 재조명하고자 함.

## 참여자

한국 대학교 재학 중인 고급 수준 EFL 학습자 169명. 듣기이해, 문법지식, 어휘 폭, 어휘 깊이, 읽기이해(영어)를 측정. 연령/학년 세부 정보(1~4학년 등) 및 성비 등은 발췌문에서 확인되지 않음.

## 연구 설계

구조방정식모형(SEM)을 이용한 상관적/예측적 설계 연구. 중재(교육 프로그램) 없이 단면 측정: 듣기이해, 문법지식, 어휘 폭, 어휘 깊이, 쓰기능력, 읽기이해를 각각 측정하는 도구를 사용함. 구체적인 검사 도구명, 문항 수, 시행 기간·빈도는 발췌문에서 확인되지 않음.

## 주요 결과와 효과크기

SEM 분석 결과 OLC(듣기·문법·어휘 폭 등을 포함한 잠재변인)와 어휘 깊이가 각각 읽기이해에 유의한 고유 기여를 하였으며, OLC의 예측력이 어휘 깊이보다 상대적으로 더 강한 것으로 나타남. 쓰기능력은 OLC와 어휘 깊이가 동일 모형에 포함되었을 때 유의한 효과를 보이지 않음. 구체적인 표준화 계수, d/g/r 값, 신뢰구간(CI), 적합도 지수(예: CFI, RMSEA) 등 수치는 발췌문에서 확인되지 않음.

## 한계

저자가 명시한 한계는 발췌문에서 구체적으로 확인되지 않음(발췌 범위가 서론·문헌고찰까지만 포함되어 있어 논의/한계 섹션 내용 미확인). 다만 연구 설계상 표본이 '고급 수준 한국 대학생 EFL 학습자'로 한정되어 있어, 초중고 학생이나 읽기 능력이 낮은 학습자, 즉 한국 EFL 아동에게 결과를 일반화하기 어려움. 선행 문법지식 측정 도구의 신뢰도 문제(이진 문법성 판단 과제 등)를 지적한 점은 본 연구가 표준화된 검사를 사용하고자 한 배경으로 언급됨.

## 학부모 시사점

- 아이의 읽기이해력을 키우기 위해서는 어휘 암기뿐 아니라 듣기이해, 문법지식 등 '말로 이해하는 능력' 전반을 함께 길러주는 것이 도움이 될 수 있음 — 근거 강도: 중 (단, 본 연구는 성인 고급 학습자 대상이라 아동에게 직접 적용하기는 제한적)
- 단어를 얼마나 많이 아는지(어휘 폭)보다, 단어의 뉘앙스·연어·형태 등을 깊이 있게 아는 어휘 깊이도 읽기이해에 별도로 중요한 역할을 할 수 있음 — 근거 강도: 중
- 쓰기 연습만으로는 읽기이해 향상에 직접적 효과가 크지 않을 수 있으며, 듣기·문법·어휘 학습과 통합적으로 접근하는 것이 더 유효할 수 있음 — 근거 강도: 약 (본 연구에서 쓰기효과가 유의하지 않았다는 결과이나, 이는 성인 대상 결과이며 아동 대상 일반화는 검증되지 않음)
- 본 연구 결과는 한국 대학생(고급 EFL 학습자)을 대상으로 한 것이므로, 초중고 자녀나 읽기 초기 학습자에게 그대로 적용하기보다는 참고 자료로만 활용하는 것이 바람직함 — 근거 강도: 약

## 근거 인용

"A total of 169 advanced Korean university EFL students were tested on listening comprehension, grammar knowledge, vocabulary breadth, vocabulary depth, and reading comprehension in English." (초록); "SEM analyses revealed that both OLC and vocabulary depth made unique contributions to reading comprehension, with OLC demonstrating relatively stronger predictive power." (초록); "Writing abilities did not show significant effects when OLC and vocabulary depth were considered in the same model." (초록)
