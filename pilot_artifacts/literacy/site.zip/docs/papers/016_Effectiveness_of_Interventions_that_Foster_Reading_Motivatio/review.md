---
schema_version: v1
title: "Effectiveness of Interventions that Foster Reading Motivation: a Meta-analysis"
authors:
  - "Lisa van der Sande"
  - "Roel van Steensel"
  - "Suzanne Fikrat-Wevers"
  - "Lidia Arends"
date: "2023"
doi: "10.1007/s10648-023-09719-3"
license: "CC BY"
journal: "Educational Psychology Review"
essence: "읽기 동기 이론(자기결정이론, 기대가치이론, 사회인지이론, 흥미이론, 성취목표이론, 귀인이론 등)에 기반한 학교 내 중재는 긍정적(affirming) 동기(d=0.38)와 외재적 동기(d=0.42), 결합 동기(d=0.17), 독해력(d=0.27)에 유의한 긍정 효과가 있었으나 부정적(undermining) 동기에는 유의한 효과가 없었다(d=-0.01)."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Effectiveness of Interventions that Foster Reading Motivation: a Meta-analysis

> **저자**: Lisa van der Sande, Roel van Steensel, Suzanne Fikrat-Wevers, Lidia Arends | **날짜**: 2023 | **DOI**: [10.1007/s10648-023-09719-3](https://doi.org/10.1007/s10648-023-09719-3)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: reading-motivation

---

## Essence

읽기 동기 이론(자기결정이론, 기대가치이론, 사회인지이론, 흥미이론, 성취목표이론, 귀인이론 등)에 기반한 학교 내 중재는 긍정적(affirming) 동기(d=0.38)와 외재적 동기(d=0.42), 결합 동기(d=0.17), 독해력(d=0.27)에 유의한 긍정 효과가 있었으나 부정적(undermining) 동기에는 유의한 효과가 없었다(d=-0.01).

## 연구 질문과 배경

읽기 동기를 촉진하는 이론기반 중재가 학생의 읽기 동기와 독해력을 실제로 향상시키는지, 그리고 어떤 동기 기제(예: 흥미 유발, 자율성 지지 등)가 특히 효과적인지를 검증하기 위한 메타분석이다. 기존 메타분석(Guthrie et al., 2007; Unrau et al., 2018; McBreen & Savage, 2020)이 범위가 좁거나 이론 기반 여부를 구분하지 않은 한계를 보완하고자 했다.

## 참여자

10개 온라인 데이터베이스 문헌 검색을 통해 총 39개의 개별 효과 연구(초기 검색 33편 + 업데이트 검색 6편)를 포함. 대상은 초등학교 1학년부터 중등학교 졸업까지의 학생(정확한 국가별 구성, 총 표본 수, EFL/ESL/L1 여부는 본문에서 확인되지 않음). 단, 외국어로서의 읽기(reading in a foreign language)에 초점을 둔 연구와 특정 장애 아동 대상 연구는 제외되었다는 점이 명시되어 있어, 본 메타분석은 기본적으로 모국어(L1) 읽기 동기 중재를 다룬 것으로 보인다(본문에서 명시적으로 L1이라 언급되지는 않음).

## 연구 설계

체계적 문헌고찰 및 메타분석. 무작위효과모형(random-effects model)을 사용해 Cohen's d 기준 평균 효과크기를 산출했으며, 범주형 중재자 분석(ANOVA 유사)과 연속형 중재자에 대한 메타회귀분석을 실시했다. 포함 기준: (a) 학교 내 실시, (b) 읽기 동기 이론에 기반, (c) 실험-통제 집단 비교, (d) 1학년~중등학교 학생 대상, (e) 읽기 동기 측정 포함. 총 39개 연구 포함. 중재 기간·빈도·회기 수는 연구별로 코딩되었으나 본 발췌에는 구체적 수치가 제시되지 않음(본문에서 확인되지 않음).

## 주요 결과와 효과크기

긍정적(affirming) 동기: d = 0.38 [0.25; 0.50] (출판편향 보정 후 0.47 [0.34; 0.60]). 외재적(extrinsic) 동기: d = 0.42. 결합(combined) 동기: d = 0.17. 부정적(undermining) 동기: d = -0.01 (유의하지 않음). 독해력(reading comprehension): d = 0.27 [0.17; 0.37] (출판편향 보정 후 0.30 [0.19; 0.40]). 흥미 유발을 목표로 한 중재가 긍정적 동기와 독해력에 특히 긍정적 효과를 보였다. 중재 총 기간이 길수록, 표본 내 남학생 비율이 높을수록 긍정적 동기에 대한 효과가 컸다. 연구자가 직접 실시한 중재가 교사가 실시한 중재보다 독해력에 더 큰 효과를 보였다. 초등학생이 중등학생보다, 일반 독자가 부진 독자보다 독해력 효과가 더 컸다. 신뢰구간이 명시되지 않은 나머지 효과크기(외재적, 결합 동기)는 본문 발췌에서 확인되지 않음.

## 한계

저자들은 Egger의 회귀검정에서 독해력 효과크기에 대해 유의한 출판편향 가능성을 발견했다(intercept=2.17, SE=0.74, t(37)=2.93, p=.01)고 밝혔으나, trim-and-fill 보정 후에도 효과크기는 오히려 커지는 방향이었다고 보고했다. 긍정적 동기에 대한 출판편향은 Egger 검정에서는 확인되지 않았다(intercept=0.83, SE=0.71, t(53)=1.17, p=.25). 코딩 신뢰도(중재 회기 수, 총 기간)가 다소 낮았던 점도 한계로 언급되었다. 본 메타분석은 외국어로서의 읽기 중재를 명시적으로 제외했으므로, 한국 EFL 아동에게 이 결과를 직접 일반화하기는 어렵다(연구 대상이 주로 모국어 읽기 상황으로 추정되며, 한국 EFL 맥락에 대한 언급은 본문에서 확인되지 않음).

## 학부모 시사점

- 읽기 동기를 이론적으로 겨냥한 중재(흥미 유발 등)는 아동의 '읽고 싶다는 마음(긍정적 동기)'과 독해력 향상에 실질적으로 도움이 될 수 있다는 근거가 있다 - 근거 강도: 중.
- 경쟁이나 보상 같은 외재적 동기 유발 중재도 동기 점수 자체는 높일 수 있으나, 이것이 장기적으로 독해력에 얼마나 이어지는지는 본 자료만으로는 확인되지 않는다 - 근거 강도: 약.
- 흥미를 자극하는 활동 중심의 접근이 특히 효과적이었다는 점은 가정에서의 읽기 지도 방식(아이가 흥미 있어하는 주제의 책 활용 등)에 참고할 만하다 - 근거 강도: 중.
- 이 연구는 외국어로서의 읽기 중재를 제외하고 진행되었으므로, 한국의 EFL 학습 환경(모국어가 아닌 영어 읽기)에 그대로 적용하기에는 주의가 필요하다 - 근거 강도: 약.

## 근거 인용

"Positive effects on affirming motivations (d = 0.38), extrinsic motivations (d = 0.42), combined motivations (d = 0.17), and reading comprehension (d = 0.27) were found. The effect on undermining motivations (d = −0.01) was not significant." (Page 2, Abstract)
"In particular, interventions that aimed to trigger interest had positive effects on affirming motivations and reading comprehension." (Page 2, Abstract)
"Studies were excluded ... (b) if the focus of the intervention was on reading in a foreign language" (Page 9)
"the effect size for affirming motivations of 0.38 [0.25;0.50] would change into 0.47 [0.34;0.60] after correction for publication bias with eight trimmed studies." (Page 12)
"For reading comprehension, Egger's linear regression test for asymmetry indicated significant publication bias (intercept = 2.17, SE = 0.74, t(37) = 2.93, p = .01)." (Page 12)
