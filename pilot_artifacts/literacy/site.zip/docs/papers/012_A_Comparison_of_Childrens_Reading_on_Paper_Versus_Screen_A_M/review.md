---
schema_version: v1
title: "A Comparison of Children’s Reading on Paper Versus Screen: A Meta-Analysis"
authors:
  - "May Irene Furenes"
  - "Natalia Kucirkova"
  - "Adriana G. Bus"
date: "2021"
doi: "10.3102/0034654321998074"
license: "CC BY"
journal: "Review of Educational Research"
essence: "이 메타분석은 1~8세 아동을 대상으로 한 39개 연구(30개 논문, 총 n=1,812명)를 종합하여 디지털북과 종이책 읽기가 이야기 이해력 및 어휘 학습에 미치는 영향을 비교했다. 단순히 디지털화만 된 전자책은 종이책보다 이해력 점수가 낮았지만, 이야기와 일치하는(story-congruent) 디지털 강화 기능이 있으면 디지털북이 종이책보다 더 나은 결과를 보였다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# A Comparison of Children’s Reading on Paper Versus Screen: A Meta-Analysis

> **저자**: May Irene Furenes, Natalia Kucirkova, Adriana G. Bus | **날짜**: 2021 | **DOI**: [10.3102/0034654321998074](https://doi.org/10.3102/0034654321998074)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: reading-comprehension

---

## Essence

이 메타분석은 1~8세 아동을 대상으로 한 39개 연구(30개 논문, 총 n=1,812명)를 종합하여 디지털북과 종이책 읽기가 이야기 이해력 및 어휘 학습에 미치는 영향을 비교했다. 단순히 디지털화만 된 전자책은 종이책보다 이해력 점수가 낮았지만, 이야기와 일치하는(story-congruent) 디지털 강화 기능이 있으면 디지털북이 종이책보다 더 나은 결과를 보였다.

## 연구 질문과 배경

아동의 읽기 매체(종이 vs 화면)가 이야기 이해와 어휘 학습에 미치는 영향에 대한 기존 연구 결과가 일관되지 않아, 매체 자체의 효과, 디지털북 내 강화 기능(디자인)의 효과, 임베디드 사전의 효과, 성인의 중재(mediation) 효과가 각각 어떻게 작용하는지 정량적으로 규명하고자 했다. 특히 기존의 '종이 우위(paper advantage)' 효과가 기존 독자(성인, 학생)에게는 입증되었으나, 1~8세 초기/신생 읽기 단계(emergent reader) 아동에게도 동일하게 적용되는지는 누적된 양적 근거가 없었다는 점이 배경이다.

## 참여자

39개 연구, 30개 논문, 총 아동 수 n=1,812명. 연령 범위 1~8세(신생/초기 읽기 단계 아동). 연구가 수행된 국가는 제한 없음(영어, 네덜란드어, 독일어, 노르웨이어로 작성된 논문 포함). EFL/ESL/L1 여부나 각 연구별 개별 표본 수, 숙달도에 대한 세부 정보는 본문에서 확인되지 않음.

## 연구 설계

체계적 문헌고찰 및 메타분석(PRISMA 흐름도 사용). 동일한 이야기의 디지털북 버전과 종이책 버전을 읽은 아동들의 사후검사(posttest) 점수를 비교한 실험연구들을 종합했다. 효과크기는 Hedges' g로 산출(양수=디지털북 유리, 음수=종이책 유리), Comprehensive Meta-Analysis 소프트웨어(Version 3.3)를 사용해 역분산 가중치를 적용한 랜덤효과모형(random-effects model)으로 통합했다. 이야기 이해력과 어휘 학습 두 영역으로 나누어 효과크기를 집계했으며, 이상치(outlier) 판정, 출판편향 검토(funnel plot, trim-and-fill, fail-safe number), 이질성 지표(Q, I², 예측구간)를 함께 보고했다. 코딩 신뢰도는 Cohen's kappa .63~1.00(19개 변수). 통제집단이 없는 연구, 사례연구, 비디오/오디오/영화와의 비교 연구, 기초 문해 기술(글자 인식, 음소인식)만 다룬 연구, 8세 초과 연구, 인공와우 이식 아동 및 자폐 진단 아동 대상 연구는 제외됨.

## 주요 결과와 효과크기

- 단순 디지털화(medium 효과)만 다른 디지털북 vs 종이책 비교: 디지털북이 이해력 점수에서 더 낮음(구체적 수치는 발췌문에서 확인되지 않음)
- 이야기와 일치하는 강화 기능(story-congruent enhancements)이 있는 디지털북은 종이책보다 우수(구체적 수치는 발췌문에서 확인되지 않음)
- 임베디드 사전: 이야기 이해력에는 효과 없거나 부정적 영향, 어휘 학습에는 긍정적 영향(구체적 수치는 발췌문에서 확인되지 않음)
- 성인의 종이책 읽기 중재(mediation)는 아동이 독립적으로 읽는 디지털북의 강화 기능보다 더 효과적(구체적 수치는 발췌문에서 확인되지 않음)
* 전반적으로 발췌된 본문에는 구체적인 Hedges' g 수치, 신뢰구간(CI), Q값, I² 등 정량적 통계치가 제시되어 있지 않음. 본문에서 확인되지 않음.

## 한계

저자들이 밝힌 한계: (1) 대부분의 원 연구에서 디지털북에 대한 기술(description)이 최소한으로만 제공되어, 저자들이 직접 도서 제목을 검색해 강화 기능을 확인해야 했음(코딩의 간접성/불확실성). (2) 출판편향 가능성(비유의미한 결과를 가진 연구는 출판되지 않을 가능성)이 있어 funnel plot과 trim-and-fill, fail-safe number로 검토함. (3) 개별 연구 간 이질성(heterogeneity)이 존재할 수 있음(Q, I², 예측구간으로 보고). 한국 EFL 아동에 대한 일반화 한계: 포함된 연구들은 영어, 네덜란드어, 독일어, 노르웨이어로 작성된 논문이며, 연구 참여 아동들이 주로 L1(모국어) 환경에서 종이책/디지털북을 읽은 것으로 보이며, 본문에서 EFL/ESL 학습자를 명시적으로 다룬 연구가 포함되었는지는 확인되지 않음. 따라서 한국 EFL 아동(제2언어로서 영어를 배우는 환경)에 대한 직접적 일반화는 어려우며, 이는 본문에서 명시적으로 확인되지 않음.

## 학부모 시사점

- 단순히 종이책을 디지털북으로 바꾸는 것만으로는 아동의 이야기 이해력 향상을 기대하기 어려우며, 오히려 낮아질 수 있음 — 근거 강도: 중
- 이야기 내용과 관련된(story-congruent) 상호작용 기능이 포함된 디지털북은 이야기 이해에 도움이 될 수 있으나, 이야기와 무관한 게임 등은 주의를 분산시켜 오히려 방해가 될 수 있음 — 근거 강도: 중
- 임베디드 사전(단어 뜻풀이 기능)은 어휘 학습에는 도움이 되지만 이야기 전체를 이해하는 데는 도움이 되지 않거나 오히려 방해가 될 수 있음 — 근거 강도: 중
- 부모(성인)가 직접 종이책을 읽어주며 상호작용하는 것이 아동이 혼자 디지털북을 읽는 것보다 더 효과적일 수 있음 — 근거 강도: 중 (단, 본 연구는 국내 EFL 아동이 아닌 주로 자국어/L1 환경 아동을 대상으로 한 것이므로 한국 EFL 학습 맥락에 그대로 적용하기는 조심스러움)

## 근거 인용

"The comparison of digital versus paper books that only differed by digitization showed lower comprehension scores for digital books." (Abstract, p.483) / "Adults' mediation during print books' reading was more effective than the enhancements in digital books read by children independently." (Abstract, p.483) / "However, with story-congruent enhancements, digital books outperformed paper books." (Abstract, p.483) / "An embedded dictionary had no or negative effect on children's story comprehension but positively affected children's vocabulary learning." (Abstract, p.483) / "We quantitatively reviewed 39 studies reported in 30 articles (n = 1,812 children)..." (Abstract, p.483)
