---
schema_version: v1
title: "Exploring the influence of the home literacy environment on early literacy and vocabulary skills in Korean–English bilingual children"
authors:
  - "Wi-Jiwoon Kim"
  - "Dongsun Yim"
date: "2024"
doi: "10.3389/fpsyg.2024.1336292"
license: "CC BY"
journal: "Frontiers in Psychology"
essence: "한국-영어 이중언어 아동(호주 거주, 4~5세)을 대상으로 가정문해환경(HLE)이 한국어·영어 초기문해 및 어휘 발달에 미치는 영향을 조사한 연구로, 부모는 한국어 문해에는 간접적 방식을, 영어 문해에는 직접적·명시적 방식을 더 많이 사용했으며, 한국어 초기문해에는 적극적·직접적 문해활동이 중요한 반면 영어 초기문해에는 간접적 방식만으로도 충분했다는 점, 그리고 가정 내 한국어 문해자원이 풍부할수록 한국어·영어·개념적 어휘 발달에 긍정적 영향을 미쳤다는 점이 확인되었다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Exploring the influence of the home literacy environment on early literacy and vocabulary skills in Korean–English bilingual children

> **저자**: Wi-Jiwoon Kim, Dongsun Yim | **날짜**: 2024 | **DOI**: [10.3389/fpsyg.2024.1336292](https://doi.org/10.3389/fpsyg.2024.1336292)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: parent-home-literacy

---

## Essence

한국-영어 이중언어 아동(호주 거주, 4~5세)을 대상으로 가정문해환경(HLE)이 한국어·영어 초기문해 및 어휘 발달에 미치는 영향을 조사한 연구로, 부모는 한국어 문해에는 간접적 방식을, 영어 문해에는 직접적·명시적 방식을 더 많이 사용했으며, 한국어 초기문해에는 적극적·직접적 문해활동이 중요한 반면 영어 초기문해에는 간접적 방식만으로도 충분했다는 점, 그리고 가정 내 한국어 문해자원이 풍부할수록 한국어·영어·개념적 어휘 발달에 긍정적 영향을 미쳤다는 점이 확인되었다.

## 연구 질문과 배경

이중언어(헤리티지 언어) 아동에서 가정문해환경과 아동 내적 문해 관련 기술(초기문해, 어휘) 간의 관계를 탐구하려는 연구로, 특히 헤리티지 언어(한국어) 유지에 있어 문해발달의 중요성에도 불구하고 관련 연구가 부족하다는 문제의식에서 출발함. 연구질문은 (1) 한국어·영어 가정문해환경의 특성은 어떠한가, (2) 가정문해환경 요인과 아동의 초기문해·어휘 기술 간 관계는 어떠한가로 제시됨.

## 참여자

호주에 거주하는 한국어-영어 이중언어 아동, 4~5세, 헤리티지 언어는 한국어. 표본 수 및 숙달도는 본문 발췌에서 확인되지 않음.

## 연구 설계

부모 설문지(가정문해환경 질문지)와 부모-자녀 공동 책읽기(shared book reading) 세션의 비디오 분석을 통해 한국어 및 영어 가정문해환경을 측정. 아동의 한국어·영어 초기문해 기술(음운인식, 자모지식, 철자지식 등) 및 한국어·영어·개념적 어휘 기술을 측정하는 상관적 설계로 보이나, 발췌본에는 구체적 통계분석 기법(회귀, 상관계수 등)이나 중재 기간·빈도가 명시되어 있지 않음. 본문에서 확인되지 않음(세부 통계기법).

## 주요 결과와 효과크기

본문 발췌에는 구체적 효과크기(d, g, r)나 신뢰구간(CI) 수치가 제시되어 있지 않음. 본문에서 확인되지 않음.

## 한계

저자가 명시한 한계는 발췌 부분에 제시되어 있지 않아 본문에서 확인되지 않음. 다만 연구 맥락상 다음과 같은 일반화 한계가 있음: (1) 연구 대상이 호주에 거주하는 한국-영어 이중언어 아동(ESL/헤리티지 언어 맥락)으로, 한국에 거주하며 영어를 외국어로 학습하는 EFL 아동과는 언어 환경(사회적 다수언어 vs 소수언어, 몰입 환경 여부)이 근본적으로 다르므로 직접 일반화하기 어려움. (2) 연령대가 4~5세 미취학 아동으로 초등 이후 한국 EFL 학습자에게 그대로 적용하기는 제한적임.

## 학부모 시사점

- 가정에서 자녀와 함께 하는 문해 활동(책읽기, 문해자원 제공)이 아동의 언어 및 어휘 발달과 관련이 있을 수 있음 - 근거 강도: 중
- 헤리티지 언어(모국어)에 대한 가정 내 적극적·직접적인 문해 지도(예: 글자-소리 관계를 명시적으로 가르치는 활동)가 해당 언어의 초기문해 발달에 도움이 될 수 있음 - 근거 강도: 중
- 반면 사회적 다수언어(영어와 같은)의 초기문해 발달에는 간접적인 노출(책이나 자료를 접하게 하는 정도)만으로도 충분할 수 있다는 시사점이 있으나, 이는 영어가 사회 전반에서 널리 쓰이는 환경(호주)의 아동을 대상으로 한 결과이므로 한국 EFL 아동에게 동일하게 적용하기는 어려움 - 근거 강도: 약
- 가정 내 모국어(한국어) 문해자원을 풍부하게 제공하는 것이 모국어뿐 아니라 영어 및 개념적 어휘 발달에도 긍정적으로 연관될 가능성이 있음 - 근거 강도: 중

## 근거 인용

"The findings indicated that parents utilized an indirect approach for Korean literacy practices, in contrast to a more direct and explicit method for English literacy practices." (Abstract, 쪽 미확인) / "However, active and direct literacy practices were found to be essential for Korean early literacy development, while indirect methods are sufficient for English early literacy skills." (Abstract, 쪽 미확인) / "Moreover, the availability of abundant Korean literacy resources at home had a positive impact on the development of Korean and English, as well as conceptual vocabulary skills." (Abstract, 쪽 미확인)
