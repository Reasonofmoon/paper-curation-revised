---
schema_version: v1
title: "The effects of glosses on English L2 incidental vocabulary learning through reading: a meta-analysis"
authors:
  - "He Sirong"
  - "Azianura Hani Shaari"
  - "Ng Lay Shi"
date: "2026"
doi: "10.3389/flang.2026.1815571"
license: "CC BY"
journal: "Frontiers in Language Sciences"
essence: "글로싱(gloss)이 붙은 읽기 자료를 통한 L2 우연적(의도치 않은) 어휘학습에서, 글로싱은 전체적으로 유의한 촉진 효과가 있었으나 연구 간 이질성이 매우 커서 이를 균일하게 강한 효과로 해석하기는 어렵다는 것이 26편의 실증연구를 종합한 메타분석의 핵심 결론이다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# The effects of glosses on English L2 incidental vocabulary learning through reading: a meta-analysis

> **저자**: He Sirong, Azianura Hani Shaari, Ng Lay Shi | **날짜**: 2026 | **DOI**: [10.3389/flang.2026.1815571](https://doi.org/10.3389/flang.2026.1815571)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: vocabulary

---

## Essence

글로싱(gloss)이 붙은 읽기 자료를 통한 L2 우연적(의도치 않은) 어휘학습에서, 글로싱은 전체적으로 유의한 촉진 효과가 있었으나 연구 간 이질성이 매우 커서 이를 균일하게 강한 효과로 해석하기는 어렵다는 것이 26편의 실증연구를 종합한 메타분석의 핵심 결론이다.

## 연구 질문과 배경

글로싱이 L2 우연적 어휘학습에 미치는 영향에 대한 선행 연구 결과가 혼재되어 있어, 이를 종합적·체계적으로 통합할 필요가 있었다. 본 연구는 Involvement Load Hypothesis Plus(ILH+) 틀 안에서 (1) 글로싱의 전반적 효과, (2) 서로 다른 글로싱 유형(하위집단) 간 효과 차이, (3) 효과를 조절하는 변인(모더레이터)이 무엇인지를 검토하고자 하였다.

## 참여자

영어를 제2언어 또는 외국어(ESL/EFL)로 배우는 학습자를 대상으로 한 26편의 실증연구를 포함하였다. 교육 수준은 대학생과 학교급 학습자(university and school-level learners)를 모더레이터로 코딩하였으나, 구체적인 연령대·학년·총 표본 수·숙달도 수치는 본문 발췌에서 확인되지 않음. 한국 관련 연구로는 Lee and Lee (2015), Ko (1995, 2012), Salehi/Kim 등 다양한 국가의 연구가 포함된 것으로 보이나, 한국 아동 EFL 학습자만을 대상으로 한 세부 정보는 본문에서 확인되지 않음.

## 연구 설계

메타분석(체계적 문헌고찰 및 정량적 통합), PROSPERO 사전등록(CRD420251237727). 26편의 실증연구를 QualSyst 도구로 질 평가하여 22편 high quality, 4편 medium quality로 분류(low quality 없음). 코딩은 두 명의 저자가 독립적으로 실시했고 Cohen's kappa = 0.92로 높은 일치도를 보였다. 조절변인으로 input modality(지면 기반/컴퓨터 기반), lexical unit type(단일어/구), treatment duration, input frequency, test length, vocabulary knowledge type(meaning recognition, meaning recall, form recognition, form recall), educational level(대학/학교급), 그리고 5개의 글로싱 하위집단(bilingual, positional, interactional, modality-based, experimental glosses)을 분석하였다. 중재의 구체적 기간·빈도는 본문에서 확인되지 않음(연구별로 상이).

## 주요 결과와 효과크기

전체 글로싱 효과는 유의한 촉진 효과로 보고되었으나, 발췌 부분에서 전체 pooled effect size의 정확한 수치(d값)는 본문에서 확인되지 않음. 다만 4편의 medium-quality 연구를 제외한 민감도 분석(sensitivity analysis)에서는 d = 0.945, 95% CI [0.777, 1.113], I2 = 89.6%로 나타나 원 결과와 유사한 패턴을 보였다. 글로싱 하위집단별로는 interactional 및 experimental 대조에서 상대적으로 더 큰 효과 추정치가, positional 및 modality-based 대조에서는 상대적으로 더 작은 효과 추정치가 나타났다(구체적 수치는 본문 발췌에서 확인되지 않음). Input frequency, test length, treatment duration, vocabulary knowledge type가 유의한 모더레이터로 확인되었으나 각각의 구체적 효과크기·CI는 발췌에서 확인되지 않음.

## 한계

저자들은 I2 = 89.6%로 나타난 바와 같이 연구 간 이질성이 매우 높다는 점을 명시하며, 전체 pooled effect를 균일하게 강한 일반 효과로 해석해서는 안 된다고 경고하였다. 또한 연구 품질 등급의 분포가 제한적이고 고르지 않아(strong 22편, moderate 4편, low 0편) 품질을 주요 모더레이터로 분석에 포함하지 못했다. 어휘지식 측면에서는 breadth(형태-의미 연결) 관련 결과에만 초점을 맞추었고 depth(의미적·형태론적·연어적 지식) 측정치는 비교 가능한 데이터가 부족하여 제외되었다. 한국 EFL 아동에 대한 일반화 측면에서, 포함된 연구들은 대학생 및 학교급 학습자를 포함하나 구체적으로 한국 아동(초등) 학습자만을 대상으로 한 연구인지, 그 연령대별 결과가 어떠한지는 본문 발췌에서 확인되지 않으며, 대다수 연구가 통제된 실험실/교실 환경에서 이루어져 사교육(학원) 환경으로의 일반화에는 제한이 있을 수 있다.

## 학부모 시사점

- 읽기 중 모르는 단어에 뜻풀이(글로스)를 제공하는 방식은 어휘 습득에 도움이 될 수 있다는 것이 여러 연구를 종합한 결과 확인되었다 — 근거 강도: 중
- 다만 그 효과의 크기는 연구마다 상당히 다르게 나타나(이질성 매우 높음), 모든 조건에서 똑같이 큰 효과를 기대하기는 어렵다 — 근거 강도: 중
- 글로스 제공 방식 중에서도 상호작용적(예: 클릭해서 보는 방식) 또는 실험적으로 설계된 방식이 단순 위치 기반(본문 옆/하단 배치)이나 모달리티 기반(그림·음성 등) 방식보다 상대적으로 더 큰 효과를 보인 경향이 있었다 — 근거 강도: 약
- 단어가 본문에 얼마나 자주 등장하는지, 시험에 포함된 단어 수, 학습 기간 등이 어휘학습 성과에 영향을 줄 수 있는 요인으로 확인되었으므로, 자녀의 읽기 학습 자료를 선택할 때 이러한 요소들을 함께 고려해볼 수 있다 — 근거 강도: 약

## 근거 인용

"The results showed that (1) glossing was associated with a significant facilitative effect on L2 incidental vocabulary learning, although this pooled estimate should be interpreted as a broad average across highly heterogeneous study conditions rather than as a uniformly robust general effect" (Page 1, Abstract); "The restricted analysis yielded a substantively similar overall pattern (d = 0.945, 95% CI [0.777, 1.113], I2 = 89.6%)" (Page 5); "different operationally defined glossing subgroups were associated with varying effect-size estimates, with interactional and experimental contrasts showing relatively larger estimates and positional and modality-based contrasts showing relatively smaller estimates" (Page 1, Abstract); "input frequency, test length, treatment duration, and vocabulary knowledge type emerged as significant moderators" (Page 1, Abstract)
