---
schema_version: v1
title: "Reading while listening meta-analysis"
authors:
  - "Virginia Clinton-Lisell"
date: "2023"
doi: "10.31219/osf.io/ku6tv"
license: "CC BY"
journal: "OSF Preprints"
essence: "읽으면서 동시에 듣기(reading while listening)는 읽기만 하는 것에 비해 전체적으로는 사소한 수준(trivial)의 이해 효과(g = 0.18)만 있었으나, 실험자가 속도를 통제한 경우에는 유의미한 효과(g = 0.41)가 나타난 반면 자기 속도 조절 조건에서는 신뢰할 만한 효과가 없었다(g = 0.06)."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Reading while listening meta-analysis

> **저자**: Virginia Clinton-Lisell | **날짜**: 2023 | **DOI**: [10.31219/osf.io/ku6tv](https://doi.org/10.31219/osf.io/ku6tv)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: reading-comprehension

---

## Essence

읽으면서 동시에 듣기(reading while listening)는 읽기만 하는 것에 비해 전체적으로는 사소한 수준(trivial)의 이해 효과(g = 0.18)만 있었으나, 실험자가 속도를 통제한 경우에는 유의미한 효과(g = 0.41)가 나타난 반면 자기 속도 조절 조건에서는 신뢰할 만한 효과가 없었다(g = 0.06).

## 연구 질문과 배경

전자책과 텍스트음성변환(TTS) 기술 보급으로 reading while listening(오디오 지원 읽기)이 널리 이용 가능해졌으나, 읽기장애가 없는 일반 독자에게 이 방법이 읽기만 하는 것에 비해 이해력에 효과가 있는지에 대한 선행연구 결과가 엇갈려(일부는 이점, 일부는 불리, 일부는 차이 없음) 이를 종합적으로 검토할 필요가 있었다. 연구질문은 (1) reading-while-listening과 reading only 간 전체 효과, (2) 상황(자기/실험자 속도), 독자(L1/L2), 텍스트(서사/설명/혼합), 음성(인간/컴퓨터 생성)에 따른 효과 변화이다.

## 참여자

체계적 문헌고찰과 메타분석으로, 30개 독립 연구(총 N = 1945, 62개 효과크기)를 포함. 참가자의 구체적 국가·학년·숙달도는 본문에서 확인되지 않음. 다만 논문 초록에서 "struggling readers"(읽기부진 학생)와 "second language learners"(제2언어 학습자)의 하위집단에 대한 언급이 있으나 해당 하위분석은 연구 수가 too few하여 일반화하기 어렵다고 명시됨. 한국 EFL 아동을 대상으로 한 연구가 포함되었는지는 본문에서 확인되지 않음.

## 연구 설계

체계적 문헌고찰 및 메타분석(systematic review and meta-analysis). Web of Science, Scopus, ERIC, ProQuest dissertations and theses, PsycInfo를 활용한 문헌 검색(총 2,273건 인용, 중복 제거 후 2,225건 스크리닝, 최종 28개 보고서·30개 독립 연구 포함). 효과크기는 Hedges' g로 산출(Meta-Essentials 도구 사용), 연구 내 다중 측정치 간 의존성은 robust variance estimation(RVE, 가정 상관 .8)으로 처리. 이질성은 I² 지수로 평가하였고 조절변인 분석(메타회귀)으로 페이싱(자기/실험자), 언어배경(L1/L2), 텍스트 장르, 음성 유형 등을 검토함. 포함 기준: 학습장애·시청각 장애 없는 참가자, 무작위배정 또는 균형설계, 텍스트와 평가언어 동일, 양 조건 텍스트 동일, 효과크기 산출 가능한 충분한 통계치, 영어로 작성된 연구.

## 주요 결과와 효과크기

전체 효과: g = 0.18, SE = 0.07, 95% CI [0.04, 0.32], p = .01 (저자는 Hedges' g 0.1을 trivial, 0.2를 small effect로 해석하여 이 결과를 "trivial"로 규정). I² = 99.80으로 매우 높은 이질성. 메타회귀 결과, 실험자 속도 조절(experimenter-paced) 조건에서는 g = 0.41, SE = 0.12, 95% CI [0.13, 0.70], p = .01로 유의미한 효과가 있었으나, 자기 속도 조절(self-paced) 조건에서는 g = 0.06, SE = 0.06, 95% CI [-0.07, 0.19], p = .34로 신뢰할 만한 효과가 없었음. 출판편향 관련 funnel plot에서 일부 비대칭성이 관찰되어 출판편향 가능성이 시사됨(Egger's test 결과 값은 발췌에 명시되지 않음, 본문에서 확인되지 않음). 읽기부진 학생 및 제2언어 학습자의 우발적 어휘습득에 대한 잠재적 이점이 언급되었으나 구체적 효과크기는 본문에서 확인되지 않음.

## 한계

전체 이질성(I²=99.80)이 매우 높아 단일 평균 효과크기의 해석에 주의가 필요하며, 저자도 조절변인 분석의 필요성을 언급함. Funnel plot에서 출판편향 가능성이 시사됨(소규모 연구 중 평균보다 큰 효과크기 쪽으로 비대칭). 읽기부진 학생 및 제2언어 학습자에 대한 하위분석은 "현재 연구 수가 너무 적어 일반화하기 어렵다(too few studies to afford generalizations)"고 저자가 명시함. 영어로 작성된 연구만 포함되어 언어적 범위가 제한됨. 참가자의 구체적 국가·연령·EFL/ESL 여부에 대한 세부 정보가 발췌에는 제시되지 않아, 한국 EFL 아동에게 이 결과를 그대로 일반화하기는 어려움(포함 연구 대상이 한국 아동인지 본문에서 확인되지 않음).

## 학부모 시사점

- 전체적으로 보면 듣기를 병행한 읽기가 읽기만 하는 것보다 이해력에 주는 이득은 크지 않다(전체 효과 g=0.18로 'trivial' 수준)는 점을 유념할 필요가 있다 — 근거 강도: 중
- 다만 오디오 속도를 성인/교사 등 외부에서 일정하게 맞춰주는 방식(실험자 페이싱)일 때는 상대적으로 더 뚜렷한 이해력 향상(g=0.41)이 관찰되었으므로, 아이가 스스로 속도를 조절하기보다 오디오 속도에 맞춰 함께 읽도록 안내하는 방식이 도움이 될 수 있다 — 근거 강도: 중
- 아이가 스스로 페이지를 넘기며 자유롭게 속도를 조절하는 자기주도 읽기-듣기 방식은 이해력 향상에 신뢰할 만한 효과가 나타나지 않았으므로, 이 방식만으로 이해력 향상을 기대하기는 어렵다 — 근거 강도: 중
- 읽기에 어려움을 겪는 아동이나 제2언어(EFL) 학습자에게 오디오 지원 읽기가 도움이 될 가능성이 언급되었으나, 관련 연구 수가 적어 아직 확실한 결론을 내리기는 이르다 — 근거 강도: 약

## 근거 인용

"a trivial overall benefit of reading while listening over reading only on comprehension was found g = .18, SE = .07, p = .01." (초록, Page 2); "this benefit appeared to be limited to studies in which reading was paced by the experimenter, g = 0.41, SE = 0.12, 95% CI = [0.13, 0.70], p = .01. There were no reliable effects of reading while listening when reading was self-paced, g = 0.06, SE = 0.06, 95% CI = [-0.07, 0.19], p = .34." (초록, Page 2); "Struggling readers' overall comprehension and second language learners' incidental vocabulary acquisition may be benefited through audio-assisted reading, but there are currently too few studies to afford generalizations on these claims." (초록, Page 2); "The I2 was 99.80 indicating a very high degree of variability across studies." (Page 11); "Based on the funnel plot in Figure 3, there is some asymmetry... This indicates publication bias." (Page 11)
