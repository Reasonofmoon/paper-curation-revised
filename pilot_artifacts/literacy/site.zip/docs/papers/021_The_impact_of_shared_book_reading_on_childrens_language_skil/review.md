---
schema_version: v1
title: "The impact of shared book reading on children's language skills: A meta-analysis"
authors:
  - "Claire Noble"
  - "Giovanni Sala"
  - "Michelle Peter"
  - "Jamie Lingwood"
  - "Caroline Rowland"
  - "Fernand Gobet"
  - "et al."
date: "2019"
doi: "10.1016/j.edurev.2019.100290"
license: "CC BY"
journal: "Educational Research Review"
essence: "공유책읽기(shared book reading) 중재가 아동의 언어발달에 미치는 효과를 메타분석한 결과, 전체 효과는 이전 메타분석들보다 작았으며(g̅ = 0.194, p = .002), 능동적 통제집단을 사용한 연구에서는 효과가 거의 없었다(g̅ = 0.028, p = .703)."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# The impact of shared book reading on children's language skills: A meta-analysis

> **저자**: Claire Noble, Giovanni Sala, Michelle Peter, Jamie Lingwood, Caroline Rowland, Fernand Gobet, et al. | **날짜**: 2019 | **DOI**: [10.1016/j.edurev.2019.100290](https://doi.org/10.1016/j.edurev.2019.100290)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: parent-home-literacy

---

## Essence

공유책읽기(shared book reading) 중재가 아동의 언어발달에 미치는 효과를 메타분석한 결과, 전체 효과는 이전 메타분석들보다 작았으며(g̅ = 0.194, p = .002), 능동적 통제집단을 사용한 연구에서는 효과가 거의 없었다(g̅ = 0.028, p = .703).

## 연구 질문과 배경

공유책읽기가 아동의 언어발달(어휘, 문법, 음운인식 등)에 긍정적 영향을 준다는 선행연구가 많으나, (1) 연구설계의 질(통제집단 유형, 무작위 배정 여부)에 따라 효과크기가 과장되었을 가능성, (2) 결과변인(어휘, 음운인식 등)에 따른 효과 차이, (3) 사회경제적지위(SES)에 따른 효과 차이, (4) 중재 기간·아동 연령·대화형 읽기 기법 사용 여부·중재 실시자·전달 방식(1:1 vs 집단) 등이 효과를 조절하는지가 명확히 규명되지 않아 이를 메타분석으로 검토함.

## 참여자

메타분석에 포함된 개별 연구들의 정확한 편수와 총 표본수는 본문 발췌에서 확인되지 않음. SES 조절변인 분석에는 전체 표본의 57%에 해당하는 연구들이 SES 정보를 보고함(중/상위 vs 저소득 2수준으로 코딩). 참가 아동은 학령전(5세 미만) 및 학령기(5~7세) 아동을 포함(연령 조절변인 기준). 연구 맥락(EFL/ESL/L1 여부 등 한국 아동 관련 정보)은 본문에서 확인되지 않음.

## 연구 설계

메타분석(meta-analysis). 효과크기 지표는 수정된 표준화평균차이(Hedges' g)를 사용하였으며, 실험집단과 통제집단의 사전-사후 평균차이를 사전검사 표준편차(pooled pre-test SD)로 표준화하고 상향편향을 보정하여 산출함(공식 본문 제시). 조절변인으로 (1) 무작위 배정 여부, (2) 통제집단 유형(능동적 vs 수동적/business-as-usual), (3) 기저선 차이, (4) 결과측정 유형(표현어휘 EV, 수용어휘 RV, 음운인식 PA, 인쇄물개념 PC, 표현언어 EL, 혼합 M), (5) 언어기술 vs 읽기전 기초기술 구분, (6) SES(중/상위 vs 저소득), (7) 중재기간(주 단위), (8) 연령(학령전 vs 학령기), (9) 대화형 읽기(dialogic) 여부, (10) 중재 실시자(연구자/교사/부모/교사+부모), (11) 전달방식(1:1 vs 집단)을 검토함. 결과변인 코딩자간 신뢰도 Cohen's kappa=0.83, 95% CI[0.80, 0.86]; SES 코딩 kappa=0.81, 95% CI[0.61, 1.00].

## 주요 결과와 효과크기

전체 평균 효과크기 g̅ = 0.194 (p = .002). 능동적 통제집단을 사용한 연구에서는 g̅ = 0.028 (p = .703)로 유의하지 않음. 추적관찰(follow-up)이 있는 연구에서도 유의하지 않음(g̅ = 0.139, p = .200). 결과변인 유형에 따른 차이는 유의하지 않음(ps ≥ .286). SES에 따른 차이도 유의하지 않음(p = .658). 그 외 조절변인들(중재기간, 연령, 대화형읽기 여부, 실시자, 전달방식)도 모두 유의하지 않음(ps ≥ .077).

## 한계

저자들은 통제집단 유형(능동 vs 수동)이 효과크기를 크게 좌우한다고 지적하며, 연구설계의 질이 낮은 연구(통제집단 없음, 사전검사 없음)를 포함한 이전 메타분석들이 효과를 과대추정했을 가능성을 언급함. 또한 SES 코딩은 전체 표본의 57%에서만 가능했다는 한계가 있음. 한국 EFL 아동 대상 연구가 발췌에 포함되어 있는지 여부는 본문에서 확인되지 않으며, 분석 대상 연구들의 언어·문화적 맥락(L1/L2/EFL/ESL 구분)에 대한 정보도 발췌에서 확인되지 않아 한국 EFL 학습자에게 일반화하기 어려움.

## 학부모 시사점

- 부모가 아이와 책을 함께 읽는 활동은 언어발달에 작지만 유의한 긍정적 효과가 있을 수 있음(g̅ = 0.194) — 근거 강도: 중

## 근거 인용

"g‾ = 0.194, p = .002" (Abstract); "negligible in studies with active control groups (g‾ = 0.028, p = .703)" (Abstract); "non-significant effects for studies with follow-ups (g‾ = 0.139, p = .200)" (Abstract); "no significant effects of differences in outcome variable (ps ≥.286), socio-economic status (p = .658), or any of our other potential moderators (ps ≥.077)" (Abstract)
