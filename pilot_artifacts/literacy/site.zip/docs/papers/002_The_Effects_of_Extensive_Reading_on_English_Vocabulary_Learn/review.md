---
schema_version: v1
title: "The Effects of Extensive Reading on English Vocabulary Learning: A Meta-analysis"
authors:
  - "Jiren Liu"
  - "Jianying Zhang"
date: "2018"
doi: "10.5539/elt.v11n6p1"
license: "CC BY"
journal: "English Language Teaching"
essence: "21편의 실증 연구(N=1,268)를 종합한 메타분석 결과, 다독(extensive reading)은 EFL 학습자의 영어 어휘 학습에 유의한 긍정적 효과를 보였으며, 한 학기(3개월 미만) 정도의 훈련 기간과 등급별 읽기자료(Graded Readers), 이해질문, 어휘연습이 특히 효과적이었다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# The Effects of Extensive Reading on English Vocabulary Learning: A Meta-analysis

> **저자**: Jiren Liu, Jianying Zhang | **날짜**: 2018 | **DOI**: [10.5539/elt.v11n6p1](https://doi.org/10.5539/elt.v11n6p1)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: extensive-reading

---

## Essence

21편의 실증 연구(N=1,268)를 종합한 메타분석 결과, 다독(extensive reading)은 EFL 학습자의 영어 어휘 학습에 유의한 긍정적 효과를 보였으며, 한 학기(3개월 미만) 정도의 훈련 기간과 등급별 읽기자료(Graded Readers), 이해질문, 어휘연습이 특히 효과적이었다.

## 연구 질문과 배경

연구질문: (1) 다독이 EFL 학습자의 영어 어휘 습득에 긍정적 영향을 미치는가? (2) 다독 프로그램의 가장 적절한 처치 기간은 얼마인가? (3) 다독에서 가장 효과적인 읽기 자료와 교수법은 무엇인가? 개별 실증 연구들이 처치 기간이 짧고 표본이 작으며 반복연구가 부족하여 다독의 보편적 효과성 판단이 어렵다는 문제의식에서 출발함.

## 참여자

EFL 환경의 학습자를 대상으로 한 21편의 실증 연구(총 N=1,268명)를 통합. 그중 17편은 통제집단이 있는 between-group(실험군-대조군) 설계이며, 4편은 통제집단 없이 pre-post 설계임. Between-group 연구의 표본 크기는 실험군 10~67명(M=31.88), 대조군 10~139명(M=35.65)이며, pre-post 연구는 12~60명(M=30). 연령/학년대는 본문에서 확인되지 않음(참여자 연령대에 대한 구체적 구분은 발췌문에 명시되지 않음). 2007~2016년 사이 발표되거나 수행된 연구, 16개 학술지 및 미출간 박사논문 2편 포함.

## 연구 설계

체계적 문헌고찰 및 메타분석(Meta-analysis). Google Scholar, ERIC, ProQuest, Cambridge Core 등에서 검색하여 2007~2016년 사이의 실증 연구 중 평균·표준편차 등 데이터가 제시된 21편을 선정(출판 연구 19편 + 미출간 박사논문 2편). Cohen's d를 표준화 효과크기로 사용, between-group 대조(17편)와 pre-post 대조(4편)로 구분하여 산출. 이질성 검정 결과 p≤0.1로 나타나 random-effect 모형을 적용. Stata 14.0으로 분석. 참가자, 훈련기간, 통제집단 유무, 읽기자료, 처치방법(도서보고서, 이해질문, 사전사용, 어휘연습, 어휘지도, 기타), 검사 사용, 검사 신뢰도 등 7개 변인으로 코딩.

## 주요 결과와 효과크기

개별 연구별 Cohen's d 값(between-group contrasts) 예시: Alavi & Keyvanshekouh (2012) d=1.25*; Al–Homoud & Schmitt (2009) d=0.52*; Cha (2009) d=0.45; Chang (2013) d=-1.77; Hamed (2014) d=4.56; Jafarpour (2014) d=1.02; Lee (2007) Study 1 d=-0.77; Lee (2007) Study 2 d=0.17; Rafatbakhsh & Alavi (2013) d=-0.13; Rashtchi & Pourmand (2014) d=0.58; Rosszell (2007) d=1.06*; Soltani (2011) d=1.45*; Teng (2015) Study 1 d=4.77*; Teng (2015) Study 2 d=2.58*. 개별 연구 간 d값의 편차가 매우 크고(음수~4.77까지), 전체 통합 효과크기(overall pooled d)의 구체적 수치와 신뢰구간(CI)은 발췌문에 제시되지 않음 - 본문에서 확인되지 않음. 초록에서는 "다독이 영어 어휘 학습에 유의한 효과가 있다"(significant effect), "한 학기(3개월 미만)가 가장 적절한 기간", "Graded Readers, 이해질문, 어휘연습이 유의한 역할을 함"이라고만 서술되어 있고 구체적 통합 d값, CI, p값은 발췌문에서 확인되지 않음.

## 한계

저자가 언급한 한계: (1) 메타분석 자체의 한계로 출판편향(publication bias) 가능성 - 이를 줄이기 위해 미출간 박사논문 2편을 포함했으나 여전히 존재할 수 있음. (2) 개별 원 연구들의 한계로 처치 기간이 상대적으로 짧고 표본 크기가 작으며 반복연구가 부족함. (3) 개별 연구 간 효과크기 이질성이 매우 커서(-1.77~4.77) random-effect 모형을 사용했으나 이러한 큰 편차 자체가 결과 해석의 불확실성을 시사함. 한국 EFL 아동 일반화 한계: 발췌문에 포함된 연구들의 참여자 연령/학년(초등/중등/대학 등 구분)이 본문에서 명확히 제시되지 않아, 한국 초등학생 등 특정 연령대 아동에게 결과를 직접 적용하기 어려움. 또한 대상 국가·언어권(예: 이란, 한국, 일본 등 혼재 가능)이 다양하여 한국 EFL 아동만을 위한 결과로 보기 어려움.

## 학부모 시사점

- 다독은 여러 EFL 연구에서 어휘 학습에 긍정적인 방향의 효과를 보이는 경향이 있어, 아이의 영어 읽기 습관을 늘리는 것이 어휘 습득에 도움이 될 가능성이 있음 — 근거 강도: 중
- 개별 연구별로 효과 크기 편차가 매우 커서(음수부터 매우 큰 값까지) 다독의 효과가 모든 상황에서 동일하게 나타나는 것은 아니므로, 특정 프로그램이 반드시 효과를 보장한다고 기대하기보다는 아이의 성향과 자료 수준에 맞춘 점진적 적용이 필요함 — 근거 강도: 약
- 본 메타분석에 따르면 약 한 학기(3개월 미만) 정도의 다독 기간이 어휘 학습에 적절했다는 결과가 있어, 너무 짧거나 지나치게 긴 기간보다는 중간 정도의 꾸준한 다독 기간을 고려해볼 수 있음 — 근거 강도: 중
- 등급별 읽기자료(Graded Readers), 이해질문, 어휘연습을 병행하는 방식이 여러 연구에서 효과적이라고 보고되었으므로, 단순히 많이 읽히기보다 이해 확인과 어휘 연습을 함께 병행하는 것이 도움이 될 수 있음 — 근거 강도: 중

## 근거 인용

"The results revealed that: (1) extensive reading has a significant effect on English vocabulary learning; (2) one semester (less than three months) is the most appropriate length of extensive reading instruction for vocabulary learning; (3) Graded Readers, comprehension questions and vocabulary exercise play significant roles as reading materials and education methods in promoting the vocabulary learning of EFL learners." (Abstract, Page 1); "Twenty–one unique effect sizes (17 effect sizes for group contrasts and 4 effect sizes for pre–post contrasts) and a total sample size of 1,268 participants were included." (Page 5, Section 4.5); "Since the heterogeneity was observed in the present study (p ≤ 0.1), random–effect model was used in it." (Page 5, Section 4.4)
