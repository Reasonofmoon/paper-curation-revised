---
schema_version: v1
title: "The Home Literacy Environment Is a Correlate, but Perhaps Not a Cause, of Variations in Children’s Language and Literacy Development"
authors:
  - "Marina L. Puglisi"
  - "Charles Hulme"
  - "Lorna G. Hamilton"
  - "Margaret J. Snowling"
date: "2017"
doi: "10.1080/10888438.2017.1346660"
license: "CC BY"
journal: "Scientific Studies of Reading"
essence: "가정문해환경(HLE)은 아동의 언어·문해 발달과 상관이 있지만, 어머니의 언어·음운 능력을 통제하면 스토리북 노출(비형식적 활동)의 예측력은 사라지고, 직접적 문해 지도(형식적 활동)만이 읽기/철자 능력에 대한 (약하지만) 유의한 예측요인으로 남는다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# The Home Literacy Environment Is a Correlate, but Perhaps Not a Cause, of Variations in Children’s Language and Literacy Development

> **저자**: Marina L. Puglisi, Charles Hulme, Lorna G. Hamilton, Margaret J. Snowling | **날짜**: 2017 | **DOI**: [10.1080/10888438.2017.1346660](https://doi.org/10.1080/10888438.2017.1346660)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: parent-home-literacy

---

## Essence

가정문해환경(HLE)은 아동의 언어·문해 발달과 상관이 있지만, 어머니의 언어·음운 능력을 통제하면 스토리북 노출(비형식적 활동)의 예측력은 사라지고, 직접적 문해 지도(형식적 활동)만이 읽기/철자 능력에 대한 (약하지만) 유의한 예측요인으로 남는다.

## 연구 질문과 배경

가정문해환경(형식적·비형식적·간접적 측정)이 어머니의 언어능력을 통제한 후에도 아동의 읽기 및 언어 기술을 예측하는지, 그리고 이 상관이 유전적 영향(부모-자녀 공유 유전자)을 반영할 가능성이 있는지를 검토함. 선행 연구들은 HLE와 문해 발달 간 관계가 유전적으로 매개될 가능성을 시사했으나(예: van Bergen et al., 2016; Rashid et al., 2005), 직접적 검증은 부족했음.

## 참여자

난독증 고위험군 아동을 대상으로 한 종단연구 코호트(취학전부터 추적), 전체 표본 N=251(언어장애 아동 포함), 정상발달 아동만 분석 시 N=162, listwise deletion 분석 시 N=112. 국가/맥락은 본문에서 확인되지 않음(EFL/ESL/L1 여부 명시 없음, 영어권 종단연구로 추정되나 명확한 국가명은 발췌에 없음).

## 연구 설계

종단 상관연구(구조방정식모형, SEM). 다섯 가지 가정문해환경 구성요소(아동 도서 수, 공유읽기 빈도, 어머니 언어/음운 능력 등 잠재변인) 측정. 취학 1년 후 아동의 언어 및 읽기/철자 결과를 예측하는 경로모형 분석. 모형 적합도: 정상발달 하위표본에서 χ2(174)=188.571, p=.213; RMSEA=.023(90% CI: .000-.043); SRMR=.055; CFI=.987; TLI=.985. 중재나 실험적 처치는 없음(관찰연구).

## 주요 결과와 효과크기

전체 표본 모형: 잠재 결과변인에 대한 설명분산(R²) = 스토리북노출 .834, 아동언어 .291, 아동읽기/철자 .187. 정상발달 하위표본(N=162): R² = 스토리북노출 .831, 아동언어 .346, 아동읽기/철자 .170. 매개효과(표준화 간접효과) 95% CI는 모두 0을 포함하여 유의하지 않음: 모성언어→스토리북노출→아동언어(95% CI = -1.103, 0.496); 모성언어→스토리북노출→아동읽기/철자(95% CI = -0.917, 0.307); 모성언어→직접문해지도→아동읽기/철자(95% CI = -0.147, 0.223). Listwise deletion 모형(N=112)에서 SES→아동읽기/철자 경로는 유의성 상실(표준화 회귀계수=.19, 유의성 이하), 직접문해지도 경로는 다소 강화(표준화 회귀계수=.20). 정상발달 하위표본에서는 SES→아동읽기/철자 경로 비유의(표준화 회귀계수=.138). 어머니 언어능력을 통제한 후 스토리북노출은 아동 언어 또는 읽기/철자 능력의 유의한 예측요인이 아니었으며, 직접문해지도는 약하지만 유의한 예측요인으로 남음(정확한 표준화 계수 수치는 본 발췌에 제시되지 않음).

## 한계

저자들은 이 연구가 관찰연구(비실험)로서 인과관계를 확정할 수 없으며, HLE-문해 상관이 유전적 영향(수동적/유발적/능동적 유전자-환경 상관)을 반영할 가능성을 배제할 수 없다고 밝힘. 표본은 난독증 고위험 아동 코호트로, 일반 아동집단에 대한 일반화에 제한이 있을 수 있음. Listwise deletion 시 표본이 N=112로 크게 줄어들며 일부 경로의 유의성이 변화함. 한국 EFL 아동에 대한 일반화: 본 연구는 모국어(L1) 문해발달 및 영어권(추정) 가정을 대상으로 한 것으로 보이며, 한국 EFL 아동의 가정 영어학습 환경에 그대로 적용하기 어려움(본문에서 EFL 맥락 언급 없음).

## 학부모 시사점

- 아이에게 책을 자주 읽어주는 것(스토리북 노출) 자체보다, 부모 자신의 언어 능력이 아동의 언어·문해 발달과 더 밀접하게 연관되어 있을 가능성이 있음 — 근거 강도: 중
- 글자·단어를 직접 가르치는 활동(형식적 문해 지도)은 부모의 언어능력을 통제한 후에도 아동의 읽기/철자 능력과 약하게나마 연관을 유지함 — 근거 강도: 중
- 가정에서의 독서 활동과 아동 문해력 간의 상관은 유전적 요인(부모-자녀 공유 성향)이 상당 부분 설명할 수 있으므로, 특정 가정활동이 아동의 문해력을 '만들어낸다'고 단정하기 어려움 — 근거 강도: 약
- 이 연구는 난독증 고위험 아동 코호트를 대상으로 한 것으로, 일반 한국 EFL 아동·영어학습 환경에 그대로 적용하기는 어려우며 추가 검증이 필요함 — 근거 강도: 약

## 근거 인용

"Latent factors describing maternal language were significant predictors of storybook exposure but not of direct literacy instruction... after accounting for variations in maternal language, storybook exposure was not a significant predictor of children's outcomes. In contrast, direct literacy instruction remained a predictor of children's reading/spelling skills." (Abstract); "the most striking result here is that once mothers' language and phonological skills are taken into account, storybook exposure is no longer a predictor of children's language or reading/spelling skills. In contrast, direct literacy instruction does remain a predictor, albeit a weak one, of children's reading/spelling skills" (Discussion, 쪽 미확인); "We argue that the relationship between early informal home literacy activities and children's language and reading skills is largely accounted for by maternal skills and may reflect genetic influences." (Abstract)
