---
schema_version: v1
title: "Heterogeneity of English Reading Skills and Its Associations with Learning Backgrounds in Korean EFL Contexts"
authors:
  - "Byungmin Lee"
  - "Hyunsoon Kim"
date: "2024"
doi: "10.15858/engtea.79.4.202412.3"
license: "CC BY"
journal: "English Teaching"
essence: "한국 특성화고 EFL 학습자 234명을 대상으로 잠재프로파일분석을 실시한 결과, 겉보기에 동질적인 학급 내에서도 해독·어휘·통사·독해 능력이 뚜렷하게 다른 4개의 이질적 하위집단(프로파일)이 존재했으며, 이러한 프로파일 소속은 과거 학습경험, 과외 독서 참여, 학습동기 등 학습배경 요인과 유의하게 연관되었다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Heterogeneity of English Reading Skills and Its Associations with Learning Backgrounds in Korean EFL Contexts

> **저자**: Byungmin Lee, Hyunsoon Kim | **날짜**: 2024 | **DOI**: [10.15858/engtea.79.4.202412.3](https://doi.org/10.15858/engtea.79.4.202412.3)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: reading-comprehension

---

## Essence

한국 특성화고 EFL 학습자 234명을 대상으로 잠재프로파일분석을 실시한 결과, 겉보기에 동질적인 학급 내에서도 해독·어휘·통사·독해 능력이 뚜렷하게 다른 4개의 이질적 하위집단(프로파일)이 존재했으며, 이러한 프로파일 소속은 과거 학습경험, 과외 독서 참여, 학습동기 등 학습배경 요인과 유의하게 연관되었다.

## 연구 질문과 배경

한국 교육 현장에서 진단적 개입(diagnostic intervention)을 위한 노력에 동기를 얻어, 같은 학교에 다니는 학생들 사이에서 이질적인 L2 읽기 기술 프로파일을 규명하고, 이후 학습자의 L2 학습 배경이 이러한 읽기 기술의 이질성에 미치는 영향을 조사하는 것을 목표로 함. 기존의 광범위한 영어 능력 점수 기반 접근은 진단적·형성적 정보를 제공하지 못해 학생의 구체적 필요와 개입 프로그램 간 불일치를 초래할 수 있다는 문제의식에서 출발함.

## 참여자

한국(Korean EFL 맥락) 특성화고등학교(vocational high school) 학생 234명(N=234) 대상. 프로파일별 인원: Profile 1 (n=46, 19.7%), Profile 2 (n=108, 46.2%), Profile 3 (n=58, 24.8%), Profile 4 (n=22, 9.4%). 구체적 학년(고1~3 등) 및 숙달도 수준에 대한 세부 정보는 본문에서 확인되지 않음.

## 연구 설계

잠재프로파일분석(LPA)을 이용한 관찰연구(횡단설계). 234명의 한국 특성화고 EFL 학습자를 대상으로 L2 단어해독, 어휘 폭, 어휘 깊이, 통사지식, 독해 5개 측정치를 사용해 LPA로 프로파일을 도출함. AIC, BIC, aBIC, LMR, BLRT, entropy 등 모델적합도 지표와 이론적 고려, 간명성 원칙을 함께 사용하여 최적 모델(4개 프로파일)을 선정함. 이후 19개 학습배경 설문 문항에 대해 EFA(최대우도추정, direct oblimin 회전)를 실시해 4개 요인(과거 긍정적 학습경험 10문항, 현재 몰입도 2문항, 과외 독서참여 2문항, 동기적 태도 3문항)을 추출하고, 이를 예측변수로 다항로지스틱회귀분석을 실시해 프로파일 소속과의 연관성을 오즈비(odds ratio)로 해석함. 별도의 교육적 개입(중재 프로그램)은 실시되지 않음.

## 주요 결과와 효과크기

Profile 1(n=46, 19.7%)은 L2 decoding에서 평균 대비 약 1.5 SD 낮음(SE=0.06), L2 syntactic knowledge에서 1.0 SD 이상 낮음(SE=0.18). 원점수 기준 Profile 1 학생은 3분간 최대 12단어를 정확히 해독한 반면, 최고 수행 집단인 Profile 4는 같은 시간에 약 100단어를 해독함. Profile 2(n=108, 46.2%)는 전체 평균과 비슷하거나 약간 낮은 수준이며, Profile 1과 어휘깊이·독해에서 신뢰구간이 중첩되어 통계적으로 유의하게 구분되지 않음. Profile 3(n=58, 24.8%)은 전 측정치에서 평균 이상이며 통사지식은 Profile 4와 신뢰구간이 중첩됨. Profile 4(n=22, 9.4%)는 전 5개 측정치에서 평균 대비 1~2 SD 높음. 다항로지스틱회귀분석 결과 프로파일 소속은 과거 긍정적 학습경험, 과외 영어독서 참여, 동기적 태도에 의해 유의하게 예측됨(구체적 오즈비 수치, p값, 신뢰구간은 발췌문에 제시되지 않음). d, g, r 등 표준화된 효과크기 지수는 본문에서 확인되지 않음.

## 한계

본 연구는 특성화고(vocational high school) 학생만을 대상으로 하여, 일반계 고등학교나 초등학생 등 다른 학령·학교 유형의 한국 EFL 학습자에게 일반화하기 어려움. 표본이 234명으로 특정 학교/지역에 국한되었을 가능성이 있으며 발췌문에서 구체적 지역·학교 수 정보는 확인되지 않음. 횡단설계로 인과관계를 단정할 수 없으며, 개입(중재) 효과를 직접 검증한 실험연구가 아니라 관찰적 상관연구임. 저자가 명시적으로 밝힌 한계는 발췌문에서 추가로 확인되지 않음. 특히 본 연구는 특성화고 고등학생을 대상으로 하므로, 초등학생 등 어린 한국 EFL 아동에게 결과를 그대로 적용하기는 어려움.

## 학부모 시사점

- 같은 학년·같은 학교에 다니는 학생이라도 해독, 어휘, 통사, 독해 능력의 개인차가 매우 크게 나타날 수 있으므로, 일률적인 학년별 교재나 진도보다는 자녀의 구체적인 강약점(예: 해독이 약한지, 어휘 폭이 좁은지)을 파악한 맞춤형 학습이 중요할 수 있음(근거 강도: 중).
- 해독과 통사지식이 매우 취약한 학생군(Profile 1)은 7년 이상의 정규 영어교육을 받았음에도 기초 해독에 어려움을 겪는 것으로 나타나, 단순히 학습기간이 길다고 기초 문해 기술이 저절로 해결되지는 않을 수 있음을 시사함(근거 강도: 중).
- 과거의 긍정적인 영어 학습 경험, 방과후·과외의 자발적 영어 독서 참여, 그리고 학습 동기가 자녀의 읽기 능력 프로파일과 유의하게 연관되어 있었으므로, 자녀가 영어를 긍정적으로 경험하고 스스로 책을 읽는 습관을 갖도록 돕는 것이 도움이 될 수 있음(근거 강도: 중).
- 어휘 폭은 넓지만 깊이(다의어, 미묘한 용법 등)가 부족한 상위권 학생의 경우, 다양한 맥락에서 반복적으로 단어를 접하는 확장형 읽기(extensive reading)가 어휘 지식의 정교화에 도움이 될 수 있다는 시사점이 있으나, 이는 본 연구의 논의(discussion) 차원의 제안이며 직접적 중재 실험 결과는 아님(근거 강도: 약).

## 근거 인용

"Profile 1 was labeled as 'Severely Weak L2 Readers with Very Low Decoding and Syntactic Knowledge' (n = 46, 19.7% of the total)... scoring nearly 1.5 SD below the average in L2 decoding (SE = 0.06) and more than 1.0 SD below in L2 syntactic knowledge (SE = 0.18)." (본문, 쪽 미확인, Page 16 영역)

"students in Profile 1 correctly decoded at most 12 words in three minutes, whereas students in Profile 4, who performed the best, decoded nearly 100 words in the same time frame." (Page 16)

"Multinomial regression analysis revealed that profile membership was significantly predicted by positive past learning experiences, extra-curricular English reading, and motivational attitudes." (초록, Page 1)

"Profile 4... exhibited relatively strong L2 vocabulary breadth knowledge, but weaker vocabulary depth knowledge... students in Profile 4 would benefit from interventions focused on deepening and sophisticating their L2 lexical knowledge... Extensive reading could further enhance their understanding and application of known words through repeated encounters in meaningful contexts" (Page 17)
