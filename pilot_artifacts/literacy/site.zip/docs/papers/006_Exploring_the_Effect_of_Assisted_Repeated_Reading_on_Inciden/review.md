---
schema_version: v1
title: "Exploring the Effect of Assisted Repeated Reading on Incidental Vocabulary Learning and Vocabulary Learning Self-Efficacy in an EFL Context"
authors:
  - "Habib Soleimani"
  - "Farnoosh Mohammaddokht"
  - "Jalil Fathi"
date: "2022"
doi: "10.3389/fpsyg.2022.851812"
license: "CC BY"
journal: "Frontiers in Psychology"
essence: "이란 EFL 중급 학습자를 대상으로 반복읽기(assisted vs unassisted)가 우연적 어휘학습과 어휘학습 자기효능감에 미치는 효과를 비교한 연구로, 두 유형 모두 어휘를 향상시켰으나 스마트폰으로 듣기를 병행한 assisted repeated reading이 어휘 습득에서 유의하게 더 큰 효과를 보였다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Exploring the Effect of Assisted Repeated Reading on Incidental Vocabulary Learning and Vocabulary Learning Self-Efficacy in an EFL Context

> **저자**: Habib Soleimani, Farnoosh Mohammaddokht, Jalil Fathi | **날짜**: 2022 | **DOI**: [10.3389/fpsyg.2022.851812](https://doi.org/10.3389/fpsyg.2022.851812)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: vocabulary

---

## Essence

이란 EFL 중급 학습자를 대상으로 반복읽기(assisted vs unassisted)가 우연적 어휘학습과 어휘학습 자기효능감에 미치는 효과를 비교한 연구로, 두 유형 모두 어휘를 향상시켰으나 스마트폰으로 듣기를 병행한 assisted repeated reading이 어휘 습득에서 유의하게 더 큰 효과를 보였다.

## 연구 질문과 배경

연구질문: (1) assisted repeated reading이 EFL 학습자의 우연적 어휘학습에 유의한 효과가 있는가? (2) assisted repeated reading이 EFL 학습자의 어휘학습 자기효능감에 유의한 효과가 있는가? 기존 문헌은 EFL 맥락에서의 반복읽기 연구, 특히 스마트폰을 활용한 assisted 반복읽기 및 어휘학습 자기효능감에 대한 연구가 부족하다는 점을 지적하며 이를 보완하고자 함.

## 참여자

이란(EFL 맥락)의 중급(intermediate) 수준 영어 학습자 45명, 언어학원의 두 개 기존 학급(intact classes)에서 모집. 무선 배정으로 unassisted 그룹(N=21, 읽기만 수행)과 assisted 그룹(N=24, 스마트폰으로 오디오를 들으며 24개의 짧은 텍스트를 반복해서 읽고 들음)으로 나뉨. 참가자의 연령·학년은 본문에서 확인되지 않음.

## 연구 설계

준실험(quasi-experimental) 설계로, 두 개의 기존 학급을 각각 assisted/unassisted 반복읽기 조건에 무선 배정. 중재 내용은 24개의 짧은 텍스트를 반복해서 읽는 것(assisted 그룹은 스마트폰으로 오디오 파일을 들으며 함께 읽음). 측정도구는 연구자 제작 어휘 시험(researcher-made vocabulary test)과 어휘학습 자기효능감 척도(vocabulary learning self-efficacy scale). 통계분석은 ANCOVA 사용. 중재 기간·회기 빈도는 본문 발췌에서 확인되지 않음.

## 주요 결과와 효과크기

ANCOVA 결과, 두 유형의 반복읽기 모두 어휘학습을 향상시켰으나 assisted repeated reading이 unassisted보다 유의하게 더 큰 어휘 습득 향상(significantly greater EFL vocabulary gains)을 보였다고 보고됨. 어휘학습 자기효능감에서는 두 집단 모두 향상되었으나 두 집단 간 유의한 차이는 없었음(not a significant difference). 구체적인 효과크기(d, g, r) 수치나 신뢰구간(CI)은 본문 발췌에서 확인되지 않음.

## 한계

본문 발췌에서 저자가 명시적으로 밝힌 한계는 확인되지 않음. 다만 연구가 이란의 EFL 성인/청소년(중급 수준) 학습자 45명, 두 개 기존 학급을 대상으로 한 소규모 준실험 연구이며, 참가자의 정확한 연령·학년(아동인지 성인인지)이 본문 발췌에 명시되어 있지 않아 한국 초·중등 EFL 아동에게 그대로 일반화하기에는 제한이 있음. 또한 연구자 제작 어휘 시험을 사용하여 표준화된 도구가 아니라는 점도 일반화의 제한 요인이 될 수 있음(본문에서 직접 언급되지는 않았으나 방법론상 확인되는 특징).

## 학부모 시사점

- 오디오를 들으며 함께 읽는 '듣기+읽기 병행' 반복읽기 활동이 단순 반복 읽기보다 어휘 습득에 더 도움이 될 가능성이 있다는 점에서, 자녀의 읽기 학습 시 오디오북이나 음성 지원 자료를 활용하는 것을 고려해볼 수 있음 — 근거 강도: 중
- 반복해서 읽고 듣는 활동은 아이의 어휘학습에 대한 자신감(자기효능감) 향상에도 도움이 될 수 있으나, 이는 오디오 지원 여부와 상관없이 반복읽기 자체의 효과로 보임 — 근거 강도: 중
- 이 연구는 이란의 EFL 성인/청소년 학습자를 대상으로 한 소규모 준실험 연구이므로, 한국의 어린 EFL 아동에게 동일한 효과가 나타날지는 추가 확인이 필요함 — 근거 강도: 약

## 근거 인용

"The results of ANCOVA revealed that although both types of repeated reading contributed to enhancing vocabulary learning of the participants, assisted repeated reading led to significantly greater EFL vocabulary gains." (Page 1, Abstract); "Additionally, the findings revealed that both assisted and unassisted repeated reading improved vocabulary learning self-efficacy of the participants and there was not a significant difference between the two types of interventions." (Page 1, Abstract); "a sample of 45 intermediate EFL students from two intact classes of a language institute were selected as the participants... unassisted group (N = 21)... assisted group (N = 24)..." (Page 1, Abstract)
