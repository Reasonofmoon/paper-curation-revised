---
schema_version: v1
title: "How do text type, prior vocabulary knowledge, and working memory capacity affect second language incidental vocabulary learning through reading?"
authors:
  - "Soomin Lim"
  - "Sang-Ki Lee"
date: "2025"
doi: "10.14746/ssllt.33236"
license: "CC BY"
journal: "Studies in Second Language Learning and Teaching"
essence: "한국 고1 학생 46명을 대상으로 서사문(narrative)과 설명문(expository) 읽기를 통한 우연적 L2 어휘학습에서 사전 어휘지식(PVK)과 작업기억용량(WMC)이 미치는 영향을 살펴본 연구로, 장기적으로는 서사문이 더 효과적이었고 WMC가 PVK보다 어휘 습득에 더 강한 영향을 미쳤다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# How do text type, prior vocabulary knowledge, and working memory capacity affect second language incidental vocabulary learning through reading?

> **저자**: Soomin Lim, Sang-Ki Lee | **날짜**: 2025 | **DOI**: [10.14746/ssllt.33236](https://doi.org/10.14746/ssllt.33236)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: vocabulary

---

## Essence

한국 고1 학생 46명을 대상으로 서사문(narrative)과 설명문(expository) 읽기를 통한 우연적 L2 어휘학습에서 사전 어휘지식(PVK)과 작업기억용량(WMC)이 미치는 영향을 살펴본 연구로, 장기적으로는 서사문이 더 효과적이었고 WMC가 PVK보다 어휘 습득에 더 강한 영향을 미쳤다.

## 연구 질문과 배경

텍스트 유형(서사문 vs 설명문), 학습자의 사전 L2 어휘지식, 작업기억용량이 읽기를 통한 우연적 L2 어휘학습에 미치는 영향을 규명하고자 함. 기존 연구들이 한 가지 텍스트 유형만 사용하거나 학습자 개인차를 충분히 고려하지 않아 결과가 일관되지 않았다는 문제의식에서 출발함(본문 Introduction 참조).

## 참여자

한국 고등학교 1학년 학생 46명(EFL 맥락). 사전 어휘지식(VLT) 기준 고집단 21명(M=26.57, SD=1.56)·저집단 16명(M=14.44, SD=3.22); 작업기억용량(RST) 기준 고집단 20명(M=29.15, SD=3.22)·저집단 17명(M=18.06, SD=5.12). 즉각 사후검사 분석에서는 텍스트 유형별로 응답 수가 나뉘어 총 74건(narrative 37, expository 37)으로 보고됨. 참가자들의 전반적 영어 숙달도 수준은 본문에서 확인되지 않음.

## 연구 설계

준실험 설계(단일집단 반복측정, 3요인: 텍스트유형×사전어휘지식×작업기억용량). 모든 참가자가 의사단어(pseudowords)가 포함된 서사문 1편과 설명문 1편을 읽고 각각 독해과제를 수행. 사전 검사로 Vocabulary Levels Test(VLT, 사전 어휘지식 측정)와 Reading Span Task(RST, 복합 작업기억폭 과제)를 실시. 읽기 직후와 2일 후(지연) 두 시점에 단어형태 재인검사(form recognition test)와 의미 재인검사(meaning recognition test)를 실시. 자료분석은 독립표본 t-검정과 3요인 반복측정 ANOVA(유의수준 .05), 효과크기는 Cohen's d(.20 이하=소, .20~.80=중, .80 이상=대) 사용.

## 주요 결과와 효과크기

즉각 사후검사(단어형태 재인): WMC 주효과 유의, F(1,66)=6.71, p<.01, eta2=.09, d=.82(대). 텍스트유형 주효과 비유의, F(1,66)=1.14, p=.28, eta2=.02, d=.28. PVK 주효과 비유의(경계선), F(1,66)=4.04, p=.05, eta2=.06, d=.74. 2요인·3요인 상호작용 모두 비유의(all p>.05). 집단별 기술통계: 서사문 전체 M=4.08, 설명문 전체 M=3.65; 고PVK M=4.35 vs 저PVK M=3.29; 고WMC M=4.40 vs 저WMC M=3.24. 즉각 의미 재인검사에서 서사문 M=3.70, 설명문 M=3.41이며, 고PVK 집단 M=4.40으로 저PVK보다 높았음(세부 통계치는 발췌에 명확히 제시되지 않음). 지연 사후검사 및 텍스트유형×WMC 상호작용에 대한 구체적 수치(F, p, d)는 본문에서 확인되지 않음(초록에서는 유의한 상호작용이 있었다고 언급되나 발췌 본문에는 해당 통계치가 제시되지 않음). 장기적으로 서사문이 설명문보다 더 효과적이었다는 것은 초록에 언급되어 있으나 해당 지연검사 수치는 발췌에 포함되지 않음.

## 한계

저자가 명시한 한계는 발췌 내에 직접 제시되지 않음(본문에서 확인되지 않음). 다만 참가자가 한국 고등학교 1학년 학생 46명으로 표본 크기가 작고 특정 연령대·학교급에 국한되어 있어, 초등학생 등 더 어린 한국 EFL 아동에게 결과를 일반화하기 어려움. 또한 의사단어(pseudowords)를 활용한 실험 설계는 실제 교실 읽기 환경과 다를 수 있어 학원 등 실제 학습 맥락 적용에는 주의가 필요함.

## 학부모 시사점

- 우연적 어휘학습에서는 아이의 작업기억용량(WMC)이 사전 어휘지식보다 더 강하게 작용하는 것으로 나타나, 어휘량 늘리기 외에도 주의집중·정보처리 능력을 키우는 활동이 도움이 될 수 있음 — 근거 강도: 중.
- 서사문(이야기책) 읽기가 장기적으로 어휘 습득에 유리할 가능성이 시사되나, 이는 초록 수준의 요약이며 세부 통계는 발췌에서 확인되지 않아 단정하기 어려움 — 근거 강도: 약.
- 텍스트 유형의 효과가 아이의 개인차(작업기억용량)에 따라 다르게 나타날 수 있다는 상호작용이 언급되었으나 구체적 수치는 확인되지 않아, '모든 아이에게 서사문이 더 낫다'는 식의 일반화는 피해야 함 — 근거 강도: 약.
- 이 연구는 한국 고등학교 1학년(46명) 대상으로, 초등·중학생 등 더 어린 한국 EFL 아동에게 그대로 적용하기는 어려우므로 학원 커리큘럼 설계 시 참고자료 정도로만 활용할 것을 권장 — 근거 강도: 중.

## 근거 인용

"The results revealed that the narrative text was more effective in aiding L2 vocabulary acquisition in the long term than the expository text. Both prior vocabulary knowledge and working memory capacity played facilitative roles in the lexical inferencing process and retention, but working memory capacity had much stronger effects throughout all the posttests." (Abstract, p.623-624); "A three-way repeated-measures ANOVA revealed statistically significant main effects of WMC, F(1, 66) = 6.71, p < .01, eta2 = .09. Its effect size was also found to be large, d = .82." (p.637, Section 4.2); "However, there were no significant main effects of the text type factor, F(1, 66) = 1.14, p = .28, eta2 = .02, d = .28, and of the PVK factor, F(1, 66) = 4.04, p = .05, eta2 = .06, d = .74." (p.637, Section 4.2)
