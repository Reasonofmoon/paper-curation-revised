---
schema_version: v1
title: "The Effectiveness of Phonological-Based Instruction in English As a Foreign Language Students at Primary School Level: A Research Synthesis"
authors:
  - "Shuting Huo"
  - "Shufen Wang"
date: "2017"
doi: "10.3389/feduc.2017.00015"
license: "CC BY"
journal: "Frontiers in Education"
essence: "EFL 초등학생 대상 음운기반 교수(phonics/음운인식 훈련)에 관한 15개 실험·준실험 연구를 종합한 연구합성으로, 음운인식·비단어 읽기(해독) 능력에는 일관되게 중간 정도의 효과가 있었으나, 실제 단어 읽기(어휘 접근·발음)와 독해에는 효과가 일관되지 않고 중앙값이 작았음."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# The Effectiveness of Phonological-Based Instruction in English As a Foreign Language Students at Primary School Level: A Research Synthesis

> **저자**: Shuting Huo, Shufen Wang | **날짜**: 2017 | **DOI**: [10.3389/feduc.2017.00015](https://doi.org/10.3389/feduc.2017.00015)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: phonics-decoding

---

## Essence

EFL 초등학생 대상 음운기반 교수(phonics/음운인식 훈련)에 관한 15개 실험·준실험 연구를 종합한 연구합성으로, 음운인식·비단어 읽기(해독) 능력에는 일관되게 중간 정도의 효과가 있었으나, 실제 단어 읽기(어휘 접근·발음)와 독해에는 효과가 일관되지 않고 중앙값이 작았음.

## 연구 질문과 배경

서구권에서 효과가 입증된 음운기반 교수(음운인식 훈련·파닉스)가 EFL(외국어로서의 영어) 맥락의 초등학생에게도 효과적인지는 충분히 연구되지 않았다는 문제의식에서, 2000~2016년 사이 출판된 EFL 초등학생 대상 실험·준실험 연구들을 체계적으로 검토하여 음운인식·문자지식, 음운해독(비단어읽기), 단어읽기(어휘접근·발음), 독해 순으로 효과성을 분석함.

## 참여자

나이지리아, 인도, 말레이시아, 일본, 중국 본토, 홍콩, 대만 등 EFL(outer circle/expanding circle) 국가의 유치원~초등 6학년(K-Grade6) 학생 대상. 총 15개 연구(17개 비교), 5편은 미출간 학위논문, 10편은 동료심사 학술지 논문. 개별 연구별 표본수·숙달도는 본문에서 확인되지 않음. 대부분 연구에서 영어는 모국어가 매개하는 학교 교과목으로 주 2~8회(중앙값 3회), 회당 30~40분 수업.

## 연구 설계

체계적 문헌고찰(research synthesis)로, PsycINFO·ERIC·Web of Science·ProQuest Dissertations and Theses Global 등 4개 데이터베이스와 주요 학술지 수기검색을 통해 2000~2016년 출판된 116편 중 20편을 1차 선별하고, What Works Clearinghouse(2014) 근거기준(RCT 또는 준실험설계, 사전점수 보고 및 ANCOVA 통제, 교사 1인 조건당 배정 시 교란효과 통제 여부 등)을 적용해 최종 15개 연구(17개 비교)를 선정. 중재는 파닉스 교수 또는 음운인식(PA) 교수이며, 전달자(연구자/컴퓨터프로그램/교사), 집단크기, 강도(기간·회기수·회당시간), 교수요소(문자지식, 이중자, 음소인식, 해독가능텍스트, 라임탐지, 시각단어, 유추파닉스, 안내읽기 등)를 코딩. 효과크기는 Hedge's g로 산출(사전점수로 보정), Cohen(1998) 기준(0.2=작음, 0.5=중간, 0.8 이상=큼) 적용하여 음운인식/문자지식, 음운해독(비단어읽기), 단어읽기(어휘접근·발음), 독해의 4개 결과영역별로 평가.

## 주요 결과와 효과크기

음운인식 및 비단어읽기(음운해독) 영역에서 효과크기 중앙값이 중간(moderate) 수준으로 일관되게 나타남. 단어읽기(어휘접근·발음) 영역의 효과크기 중앙값은 작음(small)이었고 연구 간 결과가 일관되지 않았음. 독해 영역도 연구 간 효과가 일관되지 않음. 구체적 수치(g값, CI)는 본 발췌문에는 제시되어 있지 않아 본문에서 확인되지 않음.

## 한계

저자들이 명시한 한계: 대부분의 연구가 최소 근거기준은 충족하나 방법론적 결함(예: 조건당 교사 1인만 배정되어 교란효과 통제 미흡)을 지니고 있어 편향 가능성이 있으며, 보고된 긍정적 효과는 주의해서 해석해야 함. 인과추론을 위한 엄격한 설계의 후속 연구가 필요함. 한국 EFL 아동 일반화 관련: 포함된 연구들은 나이지리아·인도·말레이시아·일본·중국·홍콩·대만 등의 맥락으로 한국은 포함되지 않았으며, 각국의 영어교육 환경(주당 수업시수, 사회경제적 지위, 모국어-영어 언어적 거리 등)이 상이하므로 한국 EFL 아동에게 직접 일반화하기는 어려움.

## 학부모 시사점

- 음운인식·파닉스(자소-음소 대응) 훈련은 아이가 낯선 단어를 소리 내어 읽는 해독 능력(비단어 읽기)을 키우는 데 도움이 될 가능성이 있음 — 근거 강도: 중
- 다만 이런 훈련만으로 실제 단어의 의미를 파악하거나(어휘 접근) 정확한 발음, 나아가 글의 내용을 이해하는 독해력까지 자동으로 좋아진다고 기대하기는 어려움 — 근거 강도: 약
- 파닉스·음운인식 학습은 아이가 소리와 글자를 연결하는 기초를 다지는 데 유용하나, 이것이 실제 읽기 능력 전체로 이어지려면 다독이나 어휘·의미 중심 지도 등 추가적인 노력이 함께 필요할 수 있음 — 근거 강도: 중
- 이 연구는 한국이 아닌 다른 EFL 국가(대만, 중국, 일본, 말레이시아 등) 아동을 대상으로 한 것이므로, 한국 아동에게 동일한 효과가 나타난다고 단정하기는 이르며 참고자료로만 활용하는 것이 바람직함 — 근거 강도: 약

## 근거 인용

"Phonological-based instruction was consistently found to be effective among primary school EFL students on reading underlying skills, including phonemic awareness and non-word reading. The median value of the effect size was moderate." (Abstract, 쪽 1); "In contrast, the effectiveness on word recognition (lexical access and pronunciation) and reading comprehension were inconsistent across studies. The median value of the effect size on word reading was small." (Abstract, 쪽 1); "We found that most studies, although meeting the minimum standards of evidence for effectiveness, suffer from methodological flaws; thus, they are potentially biased. Therefore, the positive effects reported in this study should be interpreted with caution." (Abstract, 쪽 1); "But not enough evidence has been found to support the instructional effectiveness on real word recognition and reading comprehension." (Abstract, 쪽 1)
