---
schema_version: v1
title: "Effectiveness of Treatment Approaches for Children and Adolescents with Reading Disabilities: A Meta-Analysis of Randomized Controlled Trials"
authors:
  - "Katharina Galuschka"
  - "Elena Ise"
  - "Kathrin Krick"
  - "Gerd Schulte-Körne"
date: "2014"
doi: "10.1371/journal.pone.0089900"
license: "CC BY"
journal: "PLoS ONE"
essence: "읽기장애(난독증) 아동·청소년을 대상으로 한 22편의 무작위대조시험(RCT, 총 49개 비교)을 메타분석한 결과, phonics(파닉스) instruction이 읽기·철자 수행에 미치는 효과가 통계적으로 유의한 유일한 중재 접근이었으며, 다른 접근(음소인식, 유창성, 독해, 청각훈련, 약물치료, 색채렌즈 등)은 평균 효과크기가 유의하지 않았다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Effectiveness of Treatment Approaches for Children and Adolescents with Reading Disabilities: A Meta-Analysis of Randomized Controlled Trials

> **저자**: Katharina Galuschka, Elena Ise, Kathrin Krick, Gerd Schulte-Körne | **날짜**: 2014 | **DOI**: [10.1371/journal.pone.0089900](https://doi.org/10.1371/journal.pone.0089900)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: phonics-decoding

---

## Essence

읽기장애(난독증) 아동·청소년을 대상으로 한 22편의 무작위대조시험(RCT, 총 49개 비교)을 메타분석한 결과, phonics(파닉스) instruction이 읽기·철자 수행에 미치는 효과가 통계적으로 유의한 유일한 중재 접근이었으며, 다른 접근(음소인식, 유창성, 독해, 청각훈련, 약물치료, 색채렌즈 등)은 평균 효과크기가 유의하지 않았다.

## 연구 질문과 배경

읽기장애 아동·청소년을 위한 다양한 중재 접근(음소인식, 파닉스, 유창성, 독해, 청각훈련, 약물치료, 색채렌즈 등)의 효과성을 비교하고, 효과에 영향을 미치는 요인을 탐색하는 것이 연구 목적. 기존 National Reading Panel(2000) 리뷰 이후 최신 RCT만을 포괄적으로 통합한 메타분석이 부재했다는 문제의식에서 출발함.

## 참여자

2013년 6월까지 출판된 22편의 RCT, 총 49개의 실험군-대조군 비교. 대상은 아동·청소년(성인 연구는 포함되지 않음)으로 읽기 수행이 25백분위 이하이거나 기대치보다 1SD, 1년, 1학년 이상 낮은 경우, IQ 85 이상. 모국어(mother tongue)에서 읽기 부진을 보인 경우로 한정됨(즉 모국어 기반 연구이며, EFL/L2 학습자 대상 연구는 아님). 29개 비교는 phonics instruction, 5개는 reading fluency training, 3개는 phonemic awareness instruction, 3개는 reading comprehension training, 3개는 auditory training, 2개는 medical treatment, 4개는 coloured overlays/lenses, 1개는 sunflower therapy, 1개는 motor exercises. 국가/언어권은 본문에서 확인되지 않음(발췌 범위 내).

## 연구 설계

체계적 문헌고찰 및 메타분석(RCT만 포함, 준무작위 설계 제외). ERIC, PsycINFO, PubMed, Cochrane 데이터베이스 및 미출판 자료(clinicaltrials.com, ProQuest, SSSR 메일링리스트) 검색. 효과크기는 Hedges g로 산출(사전-사후 검사, 실험군-대조군 비교, 사전검사 차이 보정 포함). 중재 기간(주 단위), 총 중재 시간(시간 단위), 세팅(집단/개별/컴퓨터), 진행자(전문가/비전문가) 등을 코딩. 분석은 표준화 측정치만 포함(19개 연구)과 비표준화 측정치 포함(22개 연구) 두 가지로 각각 수행됨.

## 주요 결과와 효과크기

phonics instruction의 평균 효과크기가 통계적으로 유의했다고 명시되어 있으나, 발췌된 본문에는 구체적인 Hedges g 수치, 신뢰구간(CI), 통계량이 제시되어 있지 않음. 본문에서 확인되지 않음(구체적 수치는 결과(Results) 섹션에 있을 것으로 추정되나 발췌 범위에는 포함되지 않음).

## 한계

저자들이 밝힌 한계: RCT 연구 자체가 이 분야에서 널리 사용되지 않아 표본 수가 제한적이며, 일부 연구는 비표준화 측정치를 사용해 효과크기 과대추정 위험이 있음(이를 보완하기 위해 표준화/비표준화 측정치를 나누어 별도 분석함). 또한 본 메타분석은 모국어(mother tongue) 읽기 부진 아동을 대상으로 하며 성인 연구는 제외되어 성인에 대한 일반화는 어려움. 한국 EFL 아동에게의 일반화 한계: 이 연구는 모국어(L1) 읽기장애 아동·청소년을 대상으로 한 것으로, 영어를 외국어(EFL)로 배우는 한국 아동과는 언어적 배경(L1 vs L2/EFL)이 다르며, 국가·문화적 맥락(예: 유럽/북미권 위주로 추정되나 본문에서 명확한 국가 정보는 확인되지 않음)도 다를 수 있어 직접적 일반화에는 주의가 필요함.

## 학부모 시사점

- 여러 중재 접근(파닉스, 음소인식, 유창성훈련, 독해훈련, 청각훈련, 약물치료, 색채렌즈 등) 중 파닉스(phonics) 지도가 읽기·철자 능력 향상에 통계적으로 유의한 효과를 보인 유일한 접근으로 보고됨 — 근거 강도: 중
- 다른 접근법(음소인식 훈련, 읽기유창성 훈련, 독해 훈련, 청각 훈련, 색채렌즈/필터, 약물치료 등)은 평균적으로 통계적 유의성에 도달하지 못했다고 보고되어, 단독으로 사용할 경우 신중한 접근이 필요함 — 근거 강도: 중
- 다만 이 연구는 모국어(L1) 읽기장애 아동을 대상으로 한 것이며 한국 EFL 아동(L2 학습자)에 대한 직접적 적용 가능성은 확인되지 않으므로, 국내 영어리딩 학원 맥락에 그대로 적용하기보다 참고자료로 활용하는 것이 바람직함 — 근거 강도: 약
- 구체적 효과크기 수치(Hedges g, 신뢰구간 등)는 본 발췌에서 확인되지 않아, 효과의 크기 자체를 단정하기는 어려움 — 근거 강도: 약

## 근거 인용

"The results revealed that phonics instruction is not only the most frequently investigated treatment approach, but also the only approach whose efficacy on reading and spelling performance in children and adolescents with reading disabilities is statistically confirmed. The mean effect sizes of the remaining treatment approaches did not reach statistical significance." (Abstract, 쪽 1) / "study subjects were children, adolescents or adults (no studies with adults could be included)...poor reading occured in mother tongue" (Page 2, Study Selection Criteria)
