---
schema_version: v1
title: "Role of Morphological Awareness and Morphological Processing in Korean Secondary School Students' English-Vocabulary Knowledge and Reading Comprehension"
authors:
  - "Eun Joo Kim"
date: "2019"
doi: "10.15858/engtea.74.2.201906.51"
license: "CC BY"
journal: "English Teaching"
essence: "한국 중·고등학생(중2, 고1) 62명을 대상으로 형태론적 인식(morphological awareness)과 형태론적 처리(morphological processing)가 영어 어휘 지식 및 읽기이해에 미치는 영향을 조사한 결과, 형태론적 처리가 아닌 형태론적 인식이 어휘 지식과 읽기이해의 변량을 유의미하게 설명하는 것으로 나타났다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Role of Morphological Awareness and Morphological Processing in Korean Secondary School Students' English-Vocabulary Knowledge and Reading Comprehension

> **저자**: Eun Joo Kim | **날짜**: 2019 | **DOI**: [10.15858/engtea.74.2.201906.51](https://doi.org/10.15858/engtea.74.2.201906.51)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: vocabulary

---

## Essence

한국 중·고등학생(중2, 고1) 62명을 대상으로 형태론적 인식(morphological awareness)과 형태론적 처리(morphological processing)가 영어 어휘 지식 및 읽기이해에 미치는 영향을 조사한 결과, 형태론적 처리가 아닌 형태론적 인식이 어휘 지식과 읽기이해의 변량을 유의미하게 설명하는 것으로 나타났다.

## 연구 질문과 배경

형태론적 지식이 어휘 및 읽기이해에 중요하다는 인식에도 불구하고 그 하위구성요소인 형태론적 인식과 형태론적 처리는 상대적으로 연구가 적었다. 이에 본 연구는 형태론적 투명성(transparency)과 형태론적 빈도(frequency) 측면에서 두 구성요소가 한국 EFL 중등학생의 어휘 지식과 읽기이해에 어떻게 기여하는지 조사하고자 하였다. 또한 한국 중등학교 수준에서 Carlisle(2000)이 보고한 것과 유사한 경향(형태론적 인식이 학년이 높은 학생의 어휘 및 읽기이해에 더 큰 영향을 미친다는 것)이 나타나는지도 확인하고자 하였다.

## 참여자

한국(EFL 맥락), 모국어가 한국어인 중등학생 총 62명(중학교 2학년/8학년 27명, 고등학교 1학년/10학년 35명). 숙달도에 대한 구체적 수치는 본문에서 확인되지 않음.

## 연구 설계

상관연구(회귀분석 기반으로 추정되나 구체적 통계 절차명은 발췌문에서 명시되지 않음). 형태론적 구조 검사(Test of Morphological Structure, TMS)와 단어 읽기 검사(Word Reading Test, WRT)를 사용하여 복합어 인식(compounding awareness), 굴절 인식(inflectional awareness), 어휘 지식, 읽기이해를 측정함. 중재나 훈련 프로그램은 없으며 단면적 측정 연구로 보임. 중재 기간·빈도 정보는 본문에서 확인되지 않음.

## 주요 결과와 효과크기

본문에서 확인되지 않음(효과크기 d, g, r, 신뢰구간 등 구체적 수치는 발췌문에 제시되어 있지 않음). 다만 질적 결과로는 "학생들의 수행이 형태론적 투명성과 빈도에 따라 다양하게 나타났으며", "형태론적 처리가 아닌 형태론적 인식이 어휘 지식과 읽기이해의 변량을 설명하였다(복합어 인식과 굴절 인식을 통제했을 때)"고 보고됨.

## 한계

저자가 명시한 한계는 발췌문에서 구체적으로 확인되지 않음. 다만 표본이 62명으로 비교적 소규모이며 한국 중등학생(중2, 고1)에 국한되어 있어, 초등학생이나 성인 학습자, 혹은 다른 EFL/ESL 맥락으로 일반화하기에는 제한적일 수 있음. 또한 영어 모국어 화자(Carlisle, 2000) 연구와의 직접 비교 결과가 어떻게 나타났는지 구체적 수치가 발췌문에 없어 판단이 제한적임.

## 학부모 시사점

- 자녀가 영어 단어의 접두사·접미사·어근 등 형태 구조를 의식적으로 분석하는 연습(형태론적 인식)이 단순히 단어를 직관적으로 처리하는 것보다 어휘력과 독해력 향상에 더 중요할 수 있음 — 근거 강도: 중
- 학년이 올라갈수록(중학교에서 고등학교로) 학습하는 단어들이 형태적으로 더 복잡해지므로, 접사나 어근을 분석하는 학습 습관을 일찍부터 길러주는 것이 도움이 될 수 있음 — 근거 강도: 약
- 단어의 형태 변화가 투명한 경우(예: move-movement)와 불투명한 경우(예: decide-decision)에 따라 학습 난이도가 다를 수 있으므로, 아이가 어려워하는 단어 유형을 파악해 맞춤형 지도를 고려할 수 있음 — 근거 강도: 약

## 근거 인용

"The results indicated that the students' performance was varied depending on morphological transparency and frequency." (Page 1, 초록) / "it was not morphological processing, but rather morphological awareness that explained variances in vocabulary knowledge and reading comprehension, when compounding awareness and inflectional awareness were controlled for." (Page 1, 초록) / "whether similar trends characterize students at the Korean secondary school level remains unclear." (Page 5)
