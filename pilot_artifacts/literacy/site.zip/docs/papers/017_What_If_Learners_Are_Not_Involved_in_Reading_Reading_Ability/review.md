---
schema_version: v1
title: "What If Learners Are Not Involved in Reading? Reading Ability and Reading Motivation of EFL Learners"
authors:
  - "Yuah V. Chon"
  - "Jihye Kim"
date: "2019"
doi: "10.15858/engtea.74.1.201903.75"
license: "CC BY"
journal: "English Teaching"
essence: "한 학기(16주) 대학 영어 읽기 강좌 동안 한국 EFL 대학생들의 읽기 동기(Reading Motivation) 하위요인이 어떻게 변화했는지를 조사한 연구로, 전체적으로 읽기 몰입(reading involvement)은 감소했고, 숙달도가 낮은 학습자에게서만 읽기 효능감(reading efficacy)이 증가하고 성적을 위한 읽기(reading for grades)가 감소했다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# What If Learners Are Not Involved in Reading? Reading Ability and Reading Motivation of EFL Learners

> **저자**: Yuah V. Chon, Jihye Kim | **날짜**: 2019 | **DOI**: [10.15858/engtea.74.1.201903.75](https://doi.org/10.15858/engtea.74.1.201903.75)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: reading-motivation

---

## Essence

한 학기(16주) 대학 영어 읽기 강좌 동안 한국 EFL 대학생들의 읽기 동기(Reading Motivation) 하위요인이 어떻게 변화했는지를 조사한 연구로, 전체적으로 읽기 몰입(reading involvement)은 감소했고, 숙달도가 낮은 학습자에게서만 읽기 효능감(reading efficacy)이 증가하고 성적을 위한 읽기(reading for grades)가 감소했다.

## 연구 질문과 배경

저자들은 (a) 한국 EFL 대학생의 L2 읽기 동기를 구성하는 하위요인을 규명하고, (b) 한 학기 동안 숙련/비숙련 학습자의 읽기 동기가 어떻게 변화하는지 관찰하며, (c) 그 하위요인들이 읽기 능력 발달에 어떻게 기여하는지를 살펴보고자 하였다. 배경으로는 L2 읽기 동기가 동적 구성 개념으로서 강좌 진행 중 변화할 수 있음에도 기존 연구들이 대부분 정적(static) 관점을 취해왔다는 점, 그리고 사전 숙달도가 동기 변화에 미치는 영향에 대한 보고가 부족하다는 점을 지적한다.

## 참여자

한국 EFL 대학 신입생 118명(의무 수강 읽기 강좌 'Freshman English 1', 16주 과정). 대학 배치고사에 따라 Group A(N=48, 상대적으로 숙련된 학습자)와 Group B(N=70, 저-중급 학습자, 비숙련 학습자)로 구분. 전공은 자연과학, 경영, 인문예술, 교육, 불교문화, 사회과학, 자유전공 등 다양. 두 집단 간 CSAT 스태나인 점수 차이 유의함(Group A: M=3.40, SD=1.35; Group B: M=4.73, SD=1.14; t=-5.785, p<.001, 스태나인은 낮을수록 숙달도 높음).

## 연구 설계

준실험적 사전-사후 설계(단일 집단, 통제집단 없음). 동일 강사가 숙련·비숙련 두 집단 모두 담당, 주 3시간씩 16주간 진행되는 의무 읽기 강좌. 읽기 동기는 Motivations for Reading Questionnaire(MRQ, Wigfield & Guthrie 기반)를 사용해 강의 전(pre-reading instruction)과 후(post-reading instruction)에 측정. 읽기 동기 하위요인: 읽기 효능감, L2 읽기의 중요성, 읽기 몰입, L2 읽기의 외재적 유용가치, 읽기 호기심, 성적을 위한 읽기. 대응표본 t검정(paired t-test) 및 선형 다중회귀분석(linear multiple regression)으로 읽기 동기 하위요인이 읽기 능력(reading proficiency)을 예측하는지 분석.

## 주요 결과와 효과크기

전체 학습자(N=118) 대상 대응표본 t검정: 읽기 효능감 M=2.84→2.95, t=-2.517, p=.013*, Cohen's d=0.23; L2 읽기 중요성 M=3.78→3.69, t=1.912, p=.058(유의하지 않음), d=0.18; 읽기 몰입 M=3.21→2.69, t=8.180, p=.000**, d=0.75; 외재적 유용가치 M=3.57→3.56, t=.140, p=.889, d=0.01; 읽기 호기심 M=3.44→3.51, t=-.985, p=.327, d=0.09; 성적을 위한 읽기 M=3.57→3.31, t=2.802, p=.006**, d=0.26.

숙련 학습자(N=48): 읽기 몰입만 유의하게 감소(M=3.44→2.87, t=6.222, p=.000**, d=0.90, 큰 효과크기). 다른 하위요인은 유의하지 않음(효능감 d=0.18, 중요성 d=0.24, 외재적 유용가치 d=0.01, 호기심 d=0.12, 성적을 위한 읽기 d=0.12).

비숙련 학습자(N=70): 읽기 효능감 유의하게 증가(M=2.65→2.78, t=-2.237, p=.029*, d=0.27, 작은 효과), 읽기 몰입 유의하게 감소(M=3.05→2.57, t=5.556, p=.000**, d=0.66, 큰 효과), 성적을 위한 읽기 유의하게 감소(M=3.57→3.21, t=3.101, p=.003**, d=0.37, 작은 효과). 다른 하위요인은 유의하지 않음.

본문 발췌에는 회귀분석의 구체적 β, R², 신뢰구간(CI) 수치는 제시되지 않음 — 본문에서 확인되지 않음. 다만 요약(abstract)에서 "읽기 효능감이 숙련 학습자에게서만 읽기 능력의 유의한 예측변인"이라는 서술은 확인됨.

## 한계

저자가 명시한 한계: 읽기 몰입 감소의 원인에 대한 설명(대학 프로그램이 사전 선정한 학술 텍스트를 읽어야 했던 맥락적 요인, 텍스트 내용이 학습자 기대만큼 흥미롭지 않았을 가능성)은 추측이며 향후 연구에서 검증 필요하다고 명시함. 통제집단 없는 단일집단 사전-사후 설계이며, 표본이 한 대학의 특정 학과 구성으로 이루어져 있어 일반화에 제한이 있을 수 있음(본문에 명시적 일반화 제한 서술은 확인되지 않음). 한국 EFL 아동에게의 일반화 한계: 본 연구 참여자는 대학 신입생(성인 학습자)이며 TOEIC 준비라는 특정 목적의 의무 강좌 맥락이므로, 초등·중등 EFL 아동 학습자에게 결과를 직접 적용하기는 어려움 — 이는 본문에 명시된 바는 아니고 검토자 주석임.

## 학부모 시사점

- 읽기 수업(특히 정해진 교재를 읽는 형태)이 진행될수록 학습자의 '읽기를 즐기는 몰입감'은 오히려 줄어들 수 있으므로, 아이가 스스로 흥미를 느끼는 읽기 자료를 선택할 기회를 주는 것이 몰입 유지에 도움이 될 수 있음 — 근거 강도: 중 (성인 대학생 대상 연구이며 효과크기는 큰 편이나 아동 대상 검증 아님)
- 상대적으로 읽기 실력이 낮은 학습자는 학기 중 읽기 효능감(자신감)이 오히려 소폭 증가할 수 있다는 결과가 있어, 조급하게 실력을 단정짓기보다 꾸준한 노출이 자신감 형성에 도움이 될 가능성 시사 — 근거 강도: 약 (효과크기 작음, d=0.27)
- '성적을 위해 읽는다'는 동기는 학기가 진행되며 자연스럽게 줄어드는 경향이 있었으므로, 성적/점수만을 강조하는 외적 동기부여보다 다른 형태의 동기(흥미, 자율 선택 등)를 함께 고려할 필요 — 근거 강도: 중
- 숙련도가 높은 학습자와 낮은 학습자에서 동기 변화 양상이 다르게 나타났으므로, 자녀의 현재 읽기 수준에 따라 동기 유지 전략을 다르게 적용할 필요가 있음 — 근거 강도: 약 (대학생 대상, 아동 일반화 불확실)

## 근거 인용

"Results indicated that reading involvement had decreased for all learners whereas the less skilled learners demonstrated an increase of reading efficacy and a drop in reading for grades." (Abstract, p.75)

"A linear multiple regression further indicated that reading efficacy was a significant predictor of reading proficiency only for the skilled learners." (Abstract, p.75)

"reading involvement dropped for both the skilled and less skilled learners (p < .01) with indications of large effect sizes (0.66 – .90). For the less skilled learners only, reading efficacy increased (p < .05) and reading for grades dropped (p < .01)." (Results section, p.85-86 부근)

"Implications are presented on how reading needs to be conducted by allowing learners to choose their own materials, which in turn may have an effect on developing more robust forms of RM." (Abstract, p.75)

"The drop in mean for reading involvement that transpired for both proficiency groups indicated that the reading course had not necessarily helped the learners form positive sentiments towards reading in English. This may have been due to a contextual factor where the L2 learners had to read academic texts pre-selected by the university program." (p.86-87)
