---
schema_version: v1
title: "Modeling the associations between L2 teacher support and EFL learners’ reading motivation: The mediating impact of reading enjoyment, anxiety, and boredom"
authors:
  - "Ali Derakhshan"
  - "Mehdi Solhi"
  - "Jean-Marc Dewaele"
  - "Farzaneh Shakki"
date: "2025"
doi: "10.14746/ssllt.40078"
license: "CC BY"
journal: "Studies in Second Language Learning and Teaching"
essence: "이란 EFL 학습자를 대상으로 한 설문조사 연구로, 교사의 학업적·개인적 지지가 L2 읽기 동기와 강한 정적 상관을 보였고, 읽기 즐거움(FLE)은 정적, 읽기 지루함(FLB)과 읽기 불안(FLA)은 부적 상관을 보였으며, 이 정서들이 교사지지와 읽기동기 관계를 매개하는 것으로 나타났다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Modeling the associations between L2 teacher support and EFL learners’ reading motivation: The mediating impact of reading enjoyment, anxiety, and boredom

> **저자**: Ali Derakhshan, Mehdi Solhi, Jean-Marc Dewaele, Farzaneh Shakki | **날짜**: 2025 | **DOI**: [10.14746/ssllt.40078](https://doi.org/10.14746/ssllt.40078)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: reading-motivation

---

## Essence

이란 EFL 학습자를 대상으로 한 설문조사 연구로, 교사의 학업적·개인적 지지가 L2 읽기 동기와 강한 정적 상관을 보였고, 읽기 즐거움(FLE)은 정적, 읽기 지루함(FLB)과 읽기 불안(FLA)은 부적 상관을 보였으며, 이 정서들이 교사지지와 읽기동기 관계를 매개하는 것으로 나타났다.

## 연구 질문과 배경

L2 교사지지(학업적/개인적)가 EFL 학습자의 읽기 동기에 미치는 영향과, 이 관계에서 외국어 읽기 즐거움(FLE), 읽기 지루함(FLB), 읽기 불안(FLA)이 매개 역할을 하는지를 규명하고자 함. 기존 연구는 교사지지-일반 L2동기 관계나 일반적 학습정서(FLE/FLB/FLA)를 다뤘으나, 읽기라는 특정 언어기술에 대한 교사지지-정서-동기 연쇄는 미탐구 영역이었음.

## 참여자

이란(Iran)의 EFL 학습자 302명(남 93명, 여 209명). 연령·학년·숙달도 수준은 본문에서 확인되지 않음. 한국 EFL 아동과는 연령대·교육맥락이 다를 가능성이 있어 직접 일반화에 주의가 필요함.

## 연구 설계

설문 기반 상관연구(구조방정식모형/SEM 추정, 매개분석). 중재나 프로그램 실시 없이 변수 간 관계를 단면(cross-sectional) 설문으로 측정. 사용 척도명(예: 교사지지 척도, FLE/FLB/FLA 척도, 읽기동기 척도)의 구체적 문항수·신뢰도는 본문 발췌에서 확인되지 않음.

## 주요 결과와 효과크기

- 교사지지(학업적·개인적)와 읽기동기: '유의하게 강한 정적 관계'로 서술됨(구체적 r/β 수치는 발췌문에서 확인되지 않음).
- 간접효과(매개, Table 4): 
  · 학업적 지지→읽기즐거움→읽기동기: 추정치 .561, 95%CI [.028, .072], p<.001
  · 학업적 지지→읽기불안→읽기동기: 추정치 -.843, 95%CI [-.135, -.035], p=.002
  · 학업적 지지→읽기지루함→읽기동기: 추정치 -.482, 95%CI [-.212, -.093], p<.001
  · 개인적 지지→읽기즐거움→읽기동기: 추정치 .803, 95%CI [.041, .050], p=.002
  · 개인적 지지→읽기불안→읽기동기: 추정치 -.424, 95%CI [-.092, -.200], p<.001
  · 개인적 지지→읽기지루함→읽기동기: 추정치 -.626, 95%CI [-.254, -.410], p<.001
- 교사지지와 학습자 정서(매개변수 포함)가 읽기동기 분산의 '절반 이상'을 설명한다고 보고됨(정확한 R² 수치는 발췌문에서 확인되지 않음).
- d, g 등 전통적 효과크기 지표는 본문에서 확인되지 않음(SEM 경로계수/CI만 제시됨).

## 한계

발췌문에서는 저자가 명시한 한계(표본의 지역적 한정성, 자기보고식 설문의 한계, 단면연구로 인한 인과관계 추론 제한 등)가 구체적으로 서술되지 않아 본문에서 확인되지 않음. 다만 표본이 이란 EFL 성인/청소년(대학생 추정) 맥락으로 보이며, 한국 초중등 EFL 아동과는 연령, 교육제도, 문화적 맥락이 상이하여 결과를 직접 적용하기 어려움. 또한 SEM 간접효과 신뢰구간 일부(예: Ind1, Ind4)에서 하한/상한 값의 부호나 크기 표기가 통상적 형식과 다르게 보고되어 해석에 주의가 필요함(원문 표 그대로 인용).

## 학부모 시사점

- 교사가 학업적으로(자료 추천, 피드백 제공 등)·정서적으로(공감, 친밀한 소통) 지지적일 때 자녀의 읽기 동기가 높아지는 경향이 보고됨 - 근거 강도: 중
- 읽기 활동에서 '즐거움'을 느끼도록 돕는 것이 읽기 동기 향상과 강하게 연결되므로, 흥미 위주의 읽기 자료 선택이 도움이 될 수 있음 - 근거 강도: 중
- 읽기 불안이나 지루함을 줄이려는 시도 자체는 필요하지만, 이 연구의 매개분석 결과는 그 과정이 단순하지 않을 수 있음을 시사하므로(예: 부적 간접효과), 불안/지루함 감소 노력과 함께 즐거움을 키우는 균형 잡힌 접근이 바람직함 - 근거 강도: 약
- 본 연구는 이란 성인/청소년 EFL 학습자 대상 상관연구이므로, 한국 EFL 아동에게 결과를 그대로 적용하기보다는 참고자료로 활용하는 것이 바람직함 - 근거 강도: 약

## 근거 인용

"The results indicated a significantly strong and positive relationship between personal and academic teacher support and reading motivation." (Abstract)
"While L2 reading boredom and anxiety exhibited strong negative correlations with the two facets of teacher support, L2 enjoyment was positively correlated." (Abstract)
"The results also revealed that over half of the variance in L2 reading motivation could be predicted by teacher support, along with the mediating influences of learner emotions." (Abstract)
"Ind1 = a1*c1 Academic teacher support to reading enjoyment to reading motivation .561 .028 .072 .001" (Table 4, p.19-20)
"Ind4 = b1*c1 Personal teacher support to reading enjoyment to reading motivation .803 .041 .050 .002" (Table 4, p.19-20)
