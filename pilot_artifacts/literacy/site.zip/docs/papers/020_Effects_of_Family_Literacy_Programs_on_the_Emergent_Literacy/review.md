---
schema_version: v1
title: "Effects of Family Literacy Programs on the Emergent Literacy Skills of Children From Low-SES Families: A Meta-Analysis"
authors:
  - "Suzanne Fikrat-Wevers"
  - "Roel van Steensel"
  - "Lidia Arends"
date: "2021"
doi: "10.3102/0034654321998075"
license: "CC BY"
journal: "Review of Educational Research"
essence: "가정문해프로그램(FLP)이 저소득층(low-SES) 가정 자녀(0-6세)의 초기 문해 기술에 미치는 효과를 다룬 메타분석으로, 즉시 사후검사에서는 중간 정도의 평균 효과(Cohen's d = 0.50), 추후검사에서는 미미한 효과(Cohen's d = 0.16)를 보였다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Effects of Family Literacy Programs on the Emergent Literacy Skills of Children From Low-SES Families: A Meta-Analysis

> **저자**: Suzanne Fikrat-Wevers, Roel van Steensel, Lidia Arends | **날짜**: 2021 | **DOI**: [10.3102/0034654321998075](https://doi.org/10.3102/0034654321998075)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: parent-home-literacy

---

## Essence

가정문해프로그램(FLP)이 저소득층(low-SES) 가정 자녀(0-6세)의 초기 문해 기술에 미치는 효과를 다룬 메타분석으로, 즉시 사후검사에서는 중간 정도의 평균 효과(Cohen's d = 0.50), 추후검사에서는 미미한 효과(Cohen's d = 0.16)를 보였다.

## 연구 질문과 배경

이 메타분석은 두 가지 연구 질문을 다룬다: (1) FLP가 저소득층 아동의 (이해관련 및 코드관련) 초기 문해 기술에 긍정적 영향을 미치는가? (2) 어떤 프로그램, 표본, 연구, 측정 특성이 프로그램 효과를 조절하는가? 기존 메타분석들은 저소득층 가정만을 대상으로 한 조절변수 분석을 수행하지 않았다는 한계에서 출발하였다.

## 참여자

저소득층(low-SES) 가정의 0-6세 아동을 주로 포함한 표본. 48개의 (준)실험 연구, 42개의 서로 다른 프로그램을 포함. 국가/EFL·ESL·L1 여부에 대한 구체적 정보는 본문에서 확인되지 않음. L2 학습자가 대상군의 상당 부분을 차지한다고 언급되나 구체적 국가나 한국 EFL 맥락에 대한 정보는 본문에서 확인되지 않음.

## 연구 설계

메타분석(meta-analysis). 48개의 (준)실험 연구(quasi-experimental studies)를 대상으로 하였으며, 실험(experiment)과 준실험(quasi-experiment)을 구분함(무작위 배정 여부 기준). Web of Science, PsycINFO, ERIC, Google Scholar 4개 데이터베이스에서 문헌 검색 수행. 조절변수로 프로그램 내용/성격(활동 유형, 언어, 대상 기술 등), 프로그램 조직/전달 방식(세팅, 트레이너 유형, 모델링/가이드 연습, 투여량), 표본 특성, 연구 특성(출판원, 연구설계, 실행충실도), 측정 특성(검사 시기, 도구 유형, 언어)을 분석함. 중재 기간·빈도에 대한 구체적 수치는 본문에서 확인되지 않음.

## 주요 결과와 효과크기

즉시 사후검사(immediate posttest): Cohen's d = 0.50 (중간 정도 평균 효과). 추후 측정(follow-up): Cohen's d = 0.16 (미미한 평균 효과). 신뢰구간(CI)은 본문 발췌에서 확인되지 않음. 선행 메타분석 인용: Manz et al.(2010) & Mol et al.(2008)에서 저소득층 가정 Cohen's d = 0.16, 소수민족 가정 d = 0.14, '위험군' 가정 d = 0.13; 고소득/다수/비위험군은 각각 d = 0.39, 0.64, 0.53. 다른 메타분석(Lonigan et al., 2008; Sénéchal & Young, 2008; van Steensel et al., 2011)은 저소득/위험군 아동에서 최대 d = 0.48까지의 평균 효과를 보고하며 유의한 차이가 없었다고 함. 세팅 관련: 가정 내 훈련 vs 센터/학교 포함 훈련 Cohen's d = 0.47 vs 0.13(Manz et al., 2010).

## 한계

저자들은 프로그램 참여로 인한 단기적 긍정 변화가 시간에 따라 어떻게 유지되는지 확인하기 위한 종단연구가 더 필요하다고 명시함(추후검사 효과가 d=0.16으로 크게 감소). 선행 메타분석들의 조절변수 분석은 저소득층과 고소득층이 혼합된 이질적 표본을 기반으로 하여 저소득층에 특화된 결론을 내리지 못했다는 한계가 있었고, 본 연구가 이를 개선하고자 함. 연구설계(실험 vs 준실험)에서 비무작위 배정은 자원자 효과(volunteer effects) 등으로 효과크기가 부풀려질 수 있음이 언급됨. 연구자 개발 검사(researcher-developed tests) 사용 시 효과가 더 크게 나타나는 경향이 있어 측정 편향 가능성이 있음. 한국 EFL 아동에 대한 일반화 가능성: 발췌된 본문에는 연구 대상 국가나 한국/EFL 맥락에 대한 구체적 언급이 없어, 한국 영어 학습 환경(EFL)에 그대로 적용하기는 어려우며 이는 본문에서 확인되지 않음.

## 학부모 시사점

- 부모가 자녀와 함께하는 가정 문해 활동(예: 책 읽어주기 등)에 참여하는 가정 문해 프로그램은 참여 직후에는 자녀의 초기 문해 기술 향상에 중간 정도의 긍정적 효과가 있을 수 있음 (Cohen's d = 0.50).
근거 강도: 중
- 다만 이러한 긍정적 효과는 시간이 지나면서 상당히 줄어드는 경향이 있어(d = 0.16), 단기 프로그램 참여만으로 장기적 문해력 향상을 기대하기보다는 지속적인 가정 내 문해 활동이 중요할 수 있음.
근거 강도: 중
- 다양한 활동(형식적 vs 비형식적, 코드 중심 vs 이해 중심)을 무분별하게 포함하기보다 특정 활동과 기술에 집중된('targeted') 프로그램이 더 효과적일 가능성이 있다고 시사되나, 이는 본 메타분석의 조절변수 분석 결과 전반에 근거한 일반적 결론이며 발췌문에는 구체적 수치가 제시되지 않음.
근거 강도: 약
- 가정 내에서 이루어지는 훈련(트레이너가 집을 방문하는 방식)이 센터/학교에서만 이루어지는 훈련보다 더 큰 효과를 보인다는 선행 연구 결과(d=0.47 vs 0.13)가 있어, 가정 내에서의 자연스러운 문해 상호작용이 도움이 될 수 있음을 시사하나 이는 저소득층 전체를 대상으로 한 것은 아니었음.
근거 강도: 약

## 근거 인용

"Outcomes of 48 (quasi-)experimental studies covering 42 different programs revealed a medium average effect of Cohen's d = 0.50 on immediate posttests and a marginal average effect of Cohen's d = 0.16 on follow-up measures." (Page 1, Abstract)
"Manz et al. (2010) and Mol et al. (2008) found marginal average effects for children from low-income families (Cohen's d = 0.16)... These effects significantly differed from effects for children from high-income, majority, and 'non-at-risk' families (Cohen's d = 0.39, 0.64, and 0.53, respectively)." (Page 3)
"Programs in which training was provided in children's homes had significantly larger effects than those in which training was also delivered in centers/schools (Cohen's d = 0.47 vs. 0.13)." (Page 5/6 - 중복 발췌 구간)
"Together, effects of different moderator variables indicate that children benefit from targeted programs that focus on a limited set of activities and skills and that are restricted to one (training) context." (Page 1, Abstract)
