---
schema_version: v1
title: "Home Literacy Environment and English as A Second Language Acquisition: A Meta-analysis"
authors:
  - "Yang Dong"
  - "Bonnie Wing-Yin Chow"
date: "2022"
doi: "10.1080/15475441.2021.2003197"
license: "CC BY"
journal: "Language Learning and Development"
essence: "가정문해환경(HLE)의 여러 요소(부모의 문해 지도 행동, 함께 책읽기, 부모 신념, 학습자원, 부모·형제자매 영향)와 아동의 EFL/ESL 수행 사이의 상관관계를 메타분석한 결과, 전반적으로 작음-중간 수준의 정적 상관이 확인되었고, 부모의 직접적 문해 지도 행동이 부모 신념이나 학습자원 보유보다 더 강한 연관성을 보였다."
review_status: "anthropic:claude-sonnet-5"
scores:
  overall: 0
---

# Home Literacy Environment and English as A Second Language Acquisition: A Meta-analysis

> **저자**: Yang Dong, Bonnie Wing-Yin Chow | **날짜**: 2022 | **DOI**: [10.1080/15475441.2021.2003197](https://doi.org/10.1080/15475441.2021.2003197)
> **리뷰 상태**: anthropic:claude-sonnet-5 | **라이선스**: CC BY | **주제**: parent-home-literacy

---

## Essence

가정문해환경(HLE)의 여러 요소(부모의 문해 지도 행동, 함께 책읽기, 부모 신념, 학습자원, 부모·형제자매 영향)와 아동의 EFL/ESL 수행 사이의 상관관계를 메타분석한 결과, 전반적으로 작음-중간 수준의 정적 상관이 확인되었고, 부모의 직접적 문해 지도 행동이 부모 신념이나 학습자원 보유보다 더 강한 연관성을 보였다.

## 연구 질문과 배경

HLE가 아동의 모국어 발달에 미치는 영향은 많이 연구되었으나 제2언어(ESL) 습득에 미치는 영향은 상대적으로 덜 알려져 있어, 저자들은 HLE 요소들(자원, 부모 참여, 함께 읽기, 부모 신념, 모/부/형제자매 효과)이 아동의 ESL 수행과 어느 정도 연관되는지, 각 요소의 상대적 중요성은 어떠한지, 가족 구성원별 영향에 차이가 있는지를 검토하고자 하였다. 연구질문은 1) HLE와 ESL 수행의 연관 정도, 2) HLE 하위요소들의 상대적 중요성, 3) 직계가족 구성원 간 차별적 영향 여부였다(본문 Page 4).

## 참여자

2000~2018년 사이 발표된 18편의 논문(2편은 복수의 상관치를 제공하여 총 22개 연구 단위)을 포함, 유치원(K)부터 초등 저학년(L, 1~3학년), 초등 고학년(H, 4~6학년), 중등(S) 학생을 대상으로 하였고 총 표본 수는 N=4401명이다. 국가/맥락은 미국, 홍콩, 중국, 인도, 히스패닉 지역 등 다양한 ESL/EFL 맥락이며, 아동의 L1은 알파벳 문자권(A) 또는 비알파벳 문자권(N)으로 구분되었다. 한국 표본은 발췌에서 확인되지 않음.

## 연구 설계

메타분석(random-effects model, Comprehensive Meta-Analysis 3.0 프로그램 사용). 개별 연구의 상관계수(r) 또는 R2를 Fisher's z로 변환하여 통합하였다. HLE를 부모 참여(parental involvement), 함께 읽기(shared reading), 부모 신념(parental beliefs), 가정 문해 자원(HLE resources), 모(maternal)·부(paternal)·형제자매(siblings) 효과의 하위 범주로 코딩하였다. 이질성(Q, I2)이 유의하거나 I2>25일 경우 조정변인 분석을 실시하였고, 출판편향은 Rosenthal's fail-safe number, funnel plot(trim-and-fill), Egger's regression test로 검토하였다(Page 5, 8).

## 주요 결과와 효과크기

Table 1에 제시된 개별 연구 수준의 상관계수(r, 괄호 안 표준오차)는 대략 .10~.66 범위였다(예: Trainin 2017, 부모참여 r=.25(.07); Author 2017, r=.66(.15); Duursma 2007, r=.39(.10) 등). 저자들은 방법론상 Cohen 기준을 적용하여 r<.10은 작은 효과, r=.30은 중간 효과, r>.50은 큰 효과로 해석한다고 명시하였다(Page 5). 다만 전체 메타분석 통합 효과크기(합산 Fisher's z 및 그에 대응하는 95% CI, 하위요소별 통합 r값)에 대한 구체적 수치는 제공된 발췌 범위 내에서 확인되지 않음. 초록에서는 "effect sizes between HLE factors and children's ESL performance was small to moderate"이며 "parental literacy teaching behaviors have stronger effects... than parental beliefs... and learning resources"라고 요약되어 있으나, 정확한 통합 r/z 수치와 CI는 발췌에 포함된 결과 섹션 부분에서 확인되지 않음.

## 한계

저자가 직접 명시한 한계는 발췌 범위 내 확인되지 않음(Results 섹션 이후 한계 논의는 발췌에 포함되지 않음). 다만 다음 사항은 발췌 내용에서 파악 가능: (1) 포함 연구의 대다수가 미국(영어가 사회적 다수언어인 ESL 맥락) 표본이며, 한국과 같이 영어가 외국어(EFL)로서 사회적 노출이 제한적인 맥락의 아동 표본은 발췌에서 확인되지 않음. (2) 표본 국가는 미국, 홍콩, 중국, 인도, 히스패닉 등으로 다양하나 한국 표본은 없어 한국 EFL 아동에게 결과를 그대로 일반화하기 어려움. (3) 일부 하위범주(예: siblings effect)는 포함 연구 수가 적어 안정적 추정이 어려울 수 있음. (4) 상관 연구 설계이므로 인과관계를 단정할 수 없음.

## 학부모 시사점

- 부모가 아이와 함께 책을 읽거나 직접적인 문해 지도(예: 어휘 가르치기, 함께 읽기)에 참여하는 것이 단순히 책을 사주거나 학습 자료를 제공하는 것보다 아동의 영어 능력과 더 밀접한 관련이 있을 수 있음 — 근거 강도: 중
- 부모의 영어 학습에 대한 긍정적 태도와 신념도 아동의 읽기 흥미나 문해 활동 참여와 관련이 있으나, 그 연관성은 직접적 지도 행동보다는 상대적으로 약한 편으로 보고됨 — 근거 강도: 약
- 어머니, 아버지, 형제자매 모두 아동의 영어 습득에 비슷한 수준으로 긍정적으로 관련될 수 있다는 결과이므로, 반드시 한 명(예: 어머니)만이 아니라 가족 구성원 전체의 참여가 도움이 될 수 있음 — 근거 강도: 중
- 이 연구는 대부분 미국 등 영어가 사회적으로 널리 쓰이는 ESL 환경의 아동을 대상으로 한 것이므로, 한국처럼 영어 노출이 제한적인 EFL 가정 환경에 그대로 적용해 효과를 기대하기는 조심스러움 — 근거 강도: 약

## 근거 인용

"Results showed the effect sizes between HLE factors and children's ESL performance was small to moderate. Family members shared a similar effect size on children's ESL performance. Parental literacy teaching behaviors have stronger effects on children's ESL ability than parental beliefs on their children's English learning and the availability of learning resources at home." (Abstract, Page 1) / "a correlation of r < .10 is considered a small effect size (Fisher's z), a correlation of r = .30 is considered a moderate effect size (Fisher's z), and a correlation of r > .50 is considered a large effect size (Fisher's z)." (Page 5, Meta-analytic procedures) / "It is expected that immediate family members have similar correlation effect size on children's ESL ability." (Page 4, The present study)
