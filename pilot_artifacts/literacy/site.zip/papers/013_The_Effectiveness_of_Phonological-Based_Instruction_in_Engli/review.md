---
schema_version: v1
title: "The Effectiveness of Phonological-Based Instruction in English As a Foreign Language Students at Primary School Level: A Research Synthesis"
authors:
  - "Shuting Huo"
  - "Shufen Wang"
date: "2017"
doi: "10.3389/feduc.2017.00015"
license: "CC BY"
journal: "Frontiers in Education"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# The Effectiveness of Phonological-Based Instruction in English As a Foreign Language Students at Primary School Level: A Research Synthesis

> **저자**: Shuting Huo, Shufen Wang | **날짜**: 2017 | **DOI**: [10.3389/feduc.2017.00015](https://doi.org/10.3389/feduc.2017.00015)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: phonics-decoding

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> May 2017 | Volume 2 | Article 15 1 Original Research published: 16 May 2017 doi: 10.3389/feduc.2017.00015 Frontiers in Education | www.frontiersin.org Edited by: Jason C. Immekus, University of Louisville, USA Reviewed by: Arturo Hernandez, University of Houston, USA G. Brian Thompson, Victoria University of Wellington, New Zealand *Correspondence: Shuting Huo huoshuting@gmail.com Specialty section: This article was submitted to Educational Psychology, a section of the journal Frontiers in Educa
