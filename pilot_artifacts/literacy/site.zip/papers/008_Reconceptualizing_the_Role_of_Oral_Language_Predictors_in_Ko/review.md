---
schema_version: v1
title: "Reconceptualizing the Role of Oral Language Predictors in Korean EFL Learners’ Reading Comprehension"
authors:
  - "Jeeyoung Park"
  - "Yusun Kang"
date: "2025"
doi: "10.15858/engtea.80.2.202506.83"
license: "CC BY"
journal: "English Teaching"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Reconceptualizing the Role of Oral Language Predictors in Korean EFL Learners’ Reading Comprehension

> **저자**: Jeeyoung Park, Yusun Kang | **날짜**: 2025 | **DOI**: [10.15858/engtea.80.2.202506.83](https://doi.org/10.15858/engtea.80.2.202506.83)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: reading-comprehension

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> English Teaching, Vol. 80, No. 2, Summer 2025, pp. 83–102 © 2025 The Korea Association of Teachers of English (KATE) DOI: https://doi.org/10.15858/engtea.80.2.202506.83 https://journal.kate.or.kr Reconceptualizing the Role of Oral Language Predictors in Korean EFL Learners’ Reading Comprehension* Jeeyoung Park and Yusun Kang** Park, Jeeyoung, & Kang, Yusun. (2025). Reconceptualizing the role of oral language predictors in Korean EFL learners’ reading comprehension. English Teaching, 80(2), 83–10
