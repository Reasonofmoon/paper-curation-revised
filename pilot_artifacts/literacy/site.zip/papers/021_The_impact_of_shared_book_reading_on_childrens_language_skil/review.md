---
schema_version: v1
title: "The impact of shared book reading on children's language skills: A meta-analysis"
authors:
  - "Claire Noble"
  - "Giovanni Sala"
  - "Michelle Peter"
  - "Jamie Lingwood"
  - "Caroline Rowland"
  - "Fernand Gobet"
  - "et al."
date: "2019"
doi: "10.1016/j.edurev.2019.100290"
license: "CC BY"
journal: "Educational Research Review"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# The impact of shared book reading on children's language skills: A meta-analysis

> **저자**: Claire Noble, Giovanni Sala, Michelle Peter, Jamie Lingwood, Caroline Rowland, Fernand Gobet, et al. | **날짜**: 2019 | **DOI**: [10.1016/j.edurev.2019.100290](https://doi.org/10.1016/j.edurev.2019.100290)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: parent-home-literacy

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> The impact of shared book reading on children's language skills: A meta-analysis Noble, C.H.; Sala, G.; Peter, M.S.; Lingwood, J.; Rowland, C.F.; Gobet, F.R.; Pine, J.M. 2019, Article / Letter to editor (Educational Research Review, 28, (2019), article 100290) Doi link to publisher: https://doi.org/10.1016/j.edurev.2019.100290 Version of the following full text: Publisher’s version Downloaded from: https://hdl.handle.net/2066/213672 Download date: 2026-09-27 Note: To cite this publication please
