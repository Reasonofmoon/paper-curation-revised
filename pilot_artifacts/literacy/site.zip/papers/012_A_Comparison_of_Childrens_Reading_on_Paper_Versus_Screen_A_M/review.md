---
schema_version: v1
title: "A Comparison of Children’s Reading on Paper Versus Screen: A Meta-Analysis"
authors:
  - "May Irene Furenes"
  - "Natalia Kucirkova"
  - "Adriana G. Bus"
date: "2021"
doi: "10.3102/0034654321998074"
license: "CC BY"
journal: "Review of Educational Research"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# A Comparison of Children’s Reading on Paper Versus Screen: A Meta-Analysis

> **저자**: May Irene Furenes, Natalia Kucirkova, Adriana G. Bus | **날짜**: 2021 | **DOI**: [10.3102/0034654321998074](https://doi.org/10.3102/0034654321998074)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: reading-comprehension

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> Review of Educational Research August 2021, Vol. 91, No. 4, pp. 483­–517 DOI:https://doi.org/10.3102/0034654321998074 Article reuse guidelines: sagepub.com/journals-permissions © 2021 The Author(s). https://journals.sagepub.com/home/rer 483 A Comparison of Children’s Reading on Paper Versus Screen: A Meta-Analysis May Irene Furenes University of Stavanger Natalia Kucirkova University of Stavanger The Open University, UK Adriana G. Bus University of Stavanger ELTE Eötvös Loránd University This me
