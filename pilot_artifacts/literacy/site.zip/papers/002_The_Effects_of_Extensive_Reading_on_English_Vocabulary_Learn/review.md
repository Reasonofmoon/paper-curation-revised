---
schema_version: v1
title: "The Effects of Extensive Reading on English Vocabulary Learning: A Meta-analysis"
authors:
  - "Jiren Liu"
  - "Jianying Zhang"
date: "2018"
doi: "10.5539/elt.v11n6p1"
license: "CC BY"
journal: "English Language Teaching"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# The Effects of Extensive Reading on English Vocabulary Learning: A Meta-analysis

> **저자**: Jiren Liu, Jianying Zhang | **날짜**: 2018 | **DOI**: [10.5539/elt.v11n6p1](https://doi.org/10.5539/elt.v11n6p1)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: extensive-reading

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> English Language Teaching; Vol. 11, No. 6; 2018 ISSN 1916-4742 E-ISSN 1916-4750 Published by Canadian Center of Science and Education 1 The Effects of Extensive Reading on English Vocabulary Learning: A Meta-analysis Jiren Liu1 & Jianying Zhang1 1 English Department, Dalian Neusoft University of Information, No. 8 Software Park Road, Dalian, China Correspondence: Jianying Zhang, English Department, Dalian Neusoft University of Information, No. 8 Software Park Road, Dalian, China. E-mail: zhangji
