---
schema_version: v1
title: "Reading while listening meta-analysis"
authors:
  - "Virginia Clinton-Lisell"
date: "2023"
doi: "10.31219/osf.io/ku6tv"
license: "CC BY"
journal: "OSF Preprints"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Reading while listening meta-analysis

> **저자**: Virginia Clinton-Lisell | **날짜**: 2023 | **DOI**: [10.31219/osf.io/ku6tv](https://doi.org/10.31219/osf.io/ku6tv)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: reading-comprehension

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> READING WHILE LISTENING 1 Does Reading While Listening to Text Improve Comprehension Compared to Reading Only? A Systematic Review and Meta-Analysis Virginia Clinton-Lisell University of North Dakota Author Note Virginia Clinton-Lisell: https://orcid.org/0000-0002-4705-2217 There are no known conflicts of interest to disclose. I thank Sofia Kafami and Yusuf Marafa for their assistance with screening and coding studies. Correspondence concerning this article should be addressed to Virginia Clinto
