---
schema_version: v1
title: "How do text type, prior vocabulary knowledge, and working memory capacity affect second language incidental vocabulary learning through reading?"
authors:
  - "Soomin Lim"
  - "Sang-Ki Lee"
date: "2025"
doi: "10.14746/ssllt.33236"
license: "CC BY"
journal: "Studies in Second Language Learning and Teaching"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# How do text type, prior vocabulary knowledge, and working memory capacity affect second language incidental vocabulary learning through reading?

> **저자**: Soomin Lim, Sang-Ki Lee | **날짜**: 2025 | **DOI**: [10.14746/ssllt.33236](https://doi.org/10.14746/ssllt.33236)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: vocabulary

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> SSLLT 15 (3) © The Author(s). Published by: Adam Mickiewicz University, 2025. Open Access article, distributed under the terms of the CC licence (CC BY 4.0, https://creativecommons.org/licenses/by/4.0/). 623 Studies in Second Language Learning and Teaching Department of English Studies, Faculty of Pedagogy and Fine Arts, Adam Mickiewicz University, Kalisz SSLLT 15 (3). 2025. 623-651. Published online: 7.05.2025 https://doi.org/10.14746/ssllt.33236 http://pressto.amu.edu.pl/index.php/ssllt How do
