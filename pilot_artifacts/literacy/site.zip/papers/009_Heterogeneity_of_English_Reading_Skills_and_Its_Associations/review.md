---
schema_version: v1
title: "Heterogeneity of English Reading Skills and Its Associations with Learning Backgrounds in Korean EFL Contexts"
authors:
  - "Byungmin Lee"
  - "Hyunsoon Kim"
date: "2024"
doi: "10.15858/engtea.79.4.202412.3"
license: "CC BY"
journal: "English Teaching"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Heterogeneity of English Reading Skills and Its Associations with Learning Backgrounds in Korean EFL Contexts

> **저자**: Byungmin Lee, Hyunsoon Kim | **날짜**: 2024 | **DOI**: [10.15858/engtea.79.4.202412.3](https://doi.org/10.15858/engtea.79.4.202412.3)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: reading-comprehension

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> English Teaching, Vol. 79, No. 4, Winter 2024, pp. 3-31 © 2024 The Korea Association of Teachers of English (KATE) This is an open access article distributed under the terms of the Creative Commons Attribution License 4.0, which permits anyone to copy, redistribute, remix, transmit and adapt the work, provided the original work and source are appropriately cited. DOI: https://doi.org/10.15858/engtea.79.4.202412.3 http://journal.kate.or.kr Heterogeneity of English Reading Skills and Its Associati
