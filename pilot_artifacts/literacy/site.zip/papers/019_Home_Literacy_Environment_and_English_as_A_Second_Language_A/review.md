---
schema_version: v1
title: "Home Literacy Environment and English as A Second Language Acquisition: A Meta-analysis"
authors:
  - "Yang Dong"
  - "Bonnie Wing-Yin Chow"
date: "2022"
doi: "10.1080/15475441.2021.2003197"
license: "CC BY"
journal: "Language Learning and Development"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Home Literacy Environment and English as A Second Language Acquisition: A Meta-analysis

> **저자**: Yang Dong, Bonnie Wing-Yin Chow | **날짜**: 2022 | **DOI**: [10.1080/15475441.2021.2003197](https://doi.org/10.1080/15475441.2021.2003197)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: parent-home-literacy

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> Language Learning and Development ISSN: 1547-5441 (Print) 1547-3341 (Online) Journal homepage: www.tandfonline.com/journals/hlld20 Home Literacy Environment and English as A Second Language Acquisition: A Meta-analysis Yang Dong & Bonnie Wing-Yin Chow To cite this article: Yang Dong & Bonnie Wing-Yin Chow (2022) Home Literacy Environment and English as A Second Language Acquisition: A Meta-analysis, Language Learning and Development, 18:4, 485-499, DOI: 10.1080/15475441.2021.2003197 To link to t
