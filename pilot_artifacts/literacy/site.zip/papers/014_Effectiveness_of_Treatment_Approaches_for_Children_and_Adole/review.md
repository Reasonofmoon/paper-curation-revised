---
schema_version: v1
title: "Effectiveness of Treatment Approaches for Children and Adolescents with Reading Disabilities: A Meta-Analysis of Randomized Controlled Trials"
authors:
  - "Katharina Galuschka"
  - "Elena Ise"
  - "Kathrin Krick"
  - "Gerd Schulte-Körne"
date: "2014"
doi: "10.1371/journal.pone.0089900"
license: "CC BY"
journal: "PLoS ONE"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Effectiveness of Treatment Approaches for Children and Adolescents with Reading Disabilities: A Meta-Analysis of Randomized Controlled Trials

> **저자**: Katharina Galuschka, Elena Ise, Kathrin Krick, Gerd Schulte-Körne | **날짜**: 2014 | **DOI**: [10.1371/journal.pone.0089900](https://doi.org/10.1371/journal.pone.0089900)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: phonics-decoding

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> Effectiveness of Treatment Approaches for Children and Adolescents with Reading Disabilities: A Meta-Analysis of Randomized Controlled Trials Katharina Galuschka1, Elena Ise2, Kathrin Krick1, Gerd Schulte-Ko¨ rne1* 1 Department of Child and Adolescent Psychiatry and Psychotherapy, University of Munich, Munich, Germany, 2 Department of Child and Adolescent Psychiatry and Psychotherapy, University of Cologne, Cologne, Germany Abstract Children and adolescents with reading disabilities experience a
