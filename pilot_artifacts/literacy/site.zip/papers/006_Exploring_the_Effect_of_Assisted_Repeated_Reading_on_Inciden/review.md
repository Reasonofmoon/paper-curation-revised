---
schema_version: v1
title: "Exploring the Effect of Assisted Repeated Reading on Incidental Vocabulary Learning and Vocabulary Learning Self-Efficacy in an EFL Context"
authors:
  - "Habib Soleimani"
  - "Farnoosh Mohammaddokht"
  - "Jalil Fathi"
date: "2022"
doi: "10.3389/fpsyg.2022.851812"
license: "CC BY"
journal: "Frontiers in Psychology"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Exploring the Effect of Assisted Repeated Reading on Incidental Vocabulary Learning and Vocabulary Learning Self-Efficacy in an EFL Context

> **저자**: Habib Soleimani, Farnoosh Mohammaddokht, Jalil Fathi | **날짜**: 2022 | **DOI**: [10.3389/fpsyg.2022.851812](https://doi.org/10.3389/fpsyg.2022.851812)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: vocabulary

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> Frontiers in Psychology | www.frontiersin.org 1 February 2022 | Volume 13 | Article 851812 ORIGINAL RESEARCH published: 18 February 2022 doi: 10.3389/fpsyg.2022.851812 Edited by: Ehsan Rassaei, Majan University College, Oman Reviewed by: Mostafa Azari Noughabi, University of Gonabad, Iran Nasim Ghanbari, Persian Gulf University, Iran *Correspondence: Jalil Fathi Jfathi13@yahoo.com orcid.org/0000-0003-1146-1024 Specialty section: This article was submitted to Language Sciences, a section of the j
