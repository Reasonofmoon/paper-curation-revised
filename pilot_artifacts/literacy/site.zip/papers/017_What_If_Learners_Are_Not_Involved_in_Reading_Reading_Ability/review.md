---
schema_version: v1
title: "What If Learners Are Not Involved in Reading? Reading Ability and Reading Motivation of EFL Learners"
authors:
  - "Yuah V. Chon"
  - "Jihye Kim"
date: "2019"
doi: "10.15858/engtea.74.1.201903.75"
license: "CC BY"
journal: "English Teaching"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# What If Learners Are Not Involved in Reading? Reading Ability and Reading Motivation of EFL Learners

> **저자**: Yuah V. Chon, Jihye Kim | **날짜**: 2019 | **DOI**: [10.15858/engtea.74.1.201903.75](https://doi.org/10.15858/engtea.74.1.201903.75)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: reading-motivation

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> 75 English Teaching, Vol. 74, No. 1, Spring 2019 DOI: 10.15858/engtea.74.1.201903.75 What If Learners Are Not Involved in Reading? Reading Ability and Reading Motivation of EFL Learners Yuah V. Chon* (Hanyang University) Jihye Kim (Dongguk University) Chon, Yuah V., & Kim, Jihye. (2019). What if learners are not involved in reading? Reading ability and reading motivation of EFL learners. English Teaching, 74(1), 75-94. During reading instruction, sustaining learners’ reading motivation (RM) may
