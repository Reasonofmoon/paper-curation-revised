---
schema_version: v1
title: "Modeling the associations between L2 teacher support and EFL learners’ reading motivation: The mediating impact of reading enjoyment, anxiety, and boredom"
authors:
  - "Ali Derakhshan"
  - "Mehdi Solhi"
  - "Jean-Marc Dewaele"
  - "Farzaneh Shakki"
date: "2025"
doi: "10.14746/ssllt.40078"
license: "CC BY"
journal: "Studies in Second Language Learning and Teaching"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Modeling the associations between L2 teacher support and EFL learners’ reading motivation: The mediating impact of reading enjoyment, anxiety, and boredom

> **저자**: Ali Derakhshan, Mehdi Solhi, Jean-Marc Dewaele, Farzaneh Shakki | **날짜**: 2025 | **DOI**: [10.14746/ssllt.40078](https://doi.org/10.14746/ssllt.40078)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: reading-motivation

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> SSLLT 15 (1) © The Author(s). Published by: Adam Mickiewicz University, 2025. Open Access article, distributed under the terms of the CC licence (BY-NC-SA, https://creativecommons.org/licenses/by-nc-sa/4.0/). 41 Studies in Second Language Learning and Teaching Department of English Studies, Faculty of Pedagogy and Fine Arts, Adam Mickiewicz University, Kalisz SSLLT 15 (1). 2025. 41-72. Published online: 10.02.2025 https://doi.org/10.14746/ssllt.40078 http://pressto.amu.edu.pl/index.php/ssllt Mod
