---
schema_version: v1
title: "The effects of glosses on English L2 incidental vocabulary learning through reading: a meta-analysis"
authors:
  - "He Sirong"
  - "Azianura Hani Shaari"
  - "Ng Lay Shi"
date: "2026"
doi: "10.3389/flang.2026.1815571"
license: "CC BY"
journal: "Frontiers in Language Sciences"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# The effects of glosses on English L2 incidental vocabulary learning through reading: a meta-analysis

> **저자**: He Sirong, Azianura Hani Shaari, Ng Lay Shi | **날짜**: 2026 | **DOI**: [10.3389/flang.2026.1815571](https://doi.org/10.3389/flang.2026.1815571)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: vocabulary

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> TYPE Systematic Review PUBLISHED 29 May 2026 DOI 10.3389/ﬂang.2026.1815571 OPEN ACCESS EDITED BY Irina Elgort, Victoria University of Wellington, New Zealand REVIEWED BY Hassan Banaruee, University of Education Weingarten, Germany Yuya Arai, Chiba University, Japan *CORRESPONDENCE He Sirong p120278@siswa.ukm.edu.my RECEIVED 23 February 2026 REVISED 09 April 2026 ACCEPTED 13 April 2026 PUBLISHED 29 May 2026 CITATION Sirong H, Shaari AH and Lay Shi N (2026) The eﬀects of glosses on English L2 inci
