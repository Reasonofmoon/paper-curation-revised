---
schema_version: v1
title: "Exploring the influence of the home literacy environment on early literacy and vocabulary skills in Korean–English bilingual children"
authors:
  - "Wi-Jiwoon Kim"
  - "Dongsun Yim"
date: "2024"
doi: "10.3389/fpsyg.2024.1336292"
license: "CC BY"
journal: "Frontiers in Psychology"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Exploring the influence of the home literacy environment on early literacy and vocabulary skills in Korean–English bilingual children

> **저자**: Wi-Jiwoon Kim, Dongsun Yim | **날짜**: 2024 | **DOI**: [10.3389/fpsyg.2024.1336292](https://doi.org/10.3389/fpsyg.2024.1336292)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: parent-home-literacy

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> Frontiers in Psychology 01 frontiersin.org Exploring the influence of the home literacy environment on early literacy and vocabulary skills in Korean–English bilingual children Wi-Jiwoon Kim and Dongsun Yim * Department of Communication Disorders, Ewha Womans University, Seoul, Republic of Korea Studies have emphasized the significance of maintaining a heritage language for various reasons such as the establishment of linguistic and cultural identity, as well as socio-emotional development. Desp
