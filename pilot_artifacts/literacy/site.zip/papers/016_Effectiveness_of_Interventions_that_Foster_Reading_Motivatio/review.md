---
schema_version: v1
title: "Effectiveness of Interventions that Foster Reading Motivation: a Meta-analysis"
authors:
  - "Lisa van der Sande"
  - "Roel van Steensel"
  - "Suzanne Fikrat-Wevers"
  - "Lidia Arends"
date: "2023"
doi: "10.1007/s10648-023-09719-3"
license: "CC BY"
journal: "Educational Psychology Review"
essence: "[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다."
review_status: "placeholder"
scores:
  overall: 0
---

# Effectiveness of Interventions that Foster Reading Motivation: a Meta-analysis

> **저자**: Lisa van der Sande, Roel van Steensel, Suzanne Fikrat-Wevers, Lidia Arends | **날짜**: 2023 | **DOI**: [10.1007/s10648-023-09719-3](https://doi.org/10.1007/s10648-023-09719-3)
> **리뷰 상태**: placeholder | **라이선스**: CC BY | **주제**: reading-motivation

---

## Essence

[PLACEHOLDER] GOOGLE_API_KEY 가 없어 Gemini 리뷰를 생성하지 않았다. 이 문장은 서지 정보만 담고, 연구의 효과를 요약하지 않는다.

## 연구 질문과 배경

본문에서 확인되지 않음 (리뷰 미생성).

## 참여자

본문에서 확인되지 않음 (리뷰 미생성).

## 연구 설계

본문에서 확인되지 않음 (리뷰 미생성).

## 주요 결과와 효과크기

본문에서 확인되지 않음 효과크기는 placeholder 리뷰에서 적지 않는다.

## 한계

본문에서 확인되지 않음 (리뷰 미생성).

## 학부모 시사점

- 리뷰가 생성되기 전에는 가정에서의 실천을 권하지 않는다.
근거 강도: 판정 불가

## 근거 인용

아래는 PDF에서 그대로 잘라 낸 앞부분이다. 해석·효과크기 환산은 하지 않았다.

> EUR Research Information Portal Effectiveness of Interventions that Foster Reading Motivation Published in: Educational Psychology Review Publication status and date: Published: 11/02/2023 DOI (link to publisher): 10.1007/s10648-023-09719-3 Document Version Publisher's PDF, also known as Version of record Document License/Available under: CC BY Citation for the published version (APA): van der Sande, L., van Steensel, R., Fikrat-Wevers, S., & Arends, L. (2023). Effectiveness of Interventions tha
